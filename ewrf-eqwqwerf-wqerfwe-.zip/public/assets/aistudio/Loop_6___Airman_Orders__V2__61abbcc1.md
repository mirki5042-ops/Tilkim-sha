# Loop 6 — Airman Orders (V2)

Part of the Tailor Shop Manager PRD v1.0 · Build only this loop, on top of finished Loops 1 to 5 · Also read the App Map, and continue from the current app (section 0)

## 0. Continue from what exists (read first)

This loop continues one app. With this document you receive the **App Map** and the **current app** (design and code) as the last loop left it.

- Never create a second copy of a screen or component that already exists. Open the existing one and change it **in place**.
- Keep the existing navigation, layout, colours and wording. Do not restyle, rename or regenerate earlier work.
- Anything new must look like it was always part of the app. Reuse the existing cards, badges, buttons, forms, dialogs, tabs, and empty and loading states.
- Each item below is marked **EXISTING** (leave alone), **EXTEND** (change in place, exactly as listed) or **NEW** (create).
- If you cannot find an existing screen or component, stop and ask me. Do not recreate it.

**EXISTING (leave alone):** every Officer screen and its behaviour, Officer order numbers, Officer customers, the status, Pay and print flows.

**EXTEND (change in place):**
- **Navigation:** add **Airman Orders** after Orders.
- **Orders screen top bar:** add **New Airman Order** beside New Order and Delivery.
- **Delivery:** add an **Officer** tab and an **Airman** tab.
- **Drafts:** show Airman drafts in the same list with an Officer or Airman badge. An Airman draft reopens in the Airman form.
- **Customers and Customer History:** add an **Airman** tab to each.
- **Settings:** add Trade, Office and Running Years lists, and the MODC Uniform item.
- **Cutting Slip page:** add the Airman variant of the same page.

**NEW:** the **Airman Orders** screen and the **New / Edit Airman Order** form. Build the Airman screen from the **same** Orders screen layout, order card, tabs, search and sort, with the uniform cards on top. Build the Airman form from the **same** order form layout. Do not design them from scratch.

## 1. Purpose and rules for the builder

Loop 6 adds the second kind of order: the yearly bulk uniform batch for **Airmen**. It has its own button, its own screen, its own form, its own order numbers and its own customers. It reuses what already exists: status, Delivery, printing the cutting slip, drafts, delete and the customer screens. When an Airman order can be taken, listed, tracked, printed and deleted, the loop is done.

**Rules**

- Build only what is written here, on top of Loops 1 to 5. Do not change Officer behaviour.
- If something is not in this document, leave it out and tell me what you left out. If something is unclear, ask.
- Airman and Officer data are completely separate: separate order numbers, separate customers, separate lists. They never mix.
- **Airman orders have no prices and no money at all.** No Total, Discount, Advance, Due, Pay or Invoice.
- Never write the word "optional" anywhere in the screen text.

## 2. What is new in this loop

1. A separate **New Airman Order** button and form.
2. An **Airman Orders** screen with uniform cards and a Running Year filter.
3. **IV-Numbers** on every item.
4. Airman support in Delivery, Drafts, Customers and the cutting slip.
5. Settings lists: **Trade**, **Office**, **Running Years**.

## 3. What changes from earlier loops

- The top bar next to New Order gets **New Airman Order**. Navigation gets an **Airman Orders** link.
- **Delivery** screen gets two tabs: **Officer** and **Airman**.
- **Drafts** list shows both kinds, each with an "Officer" or "Airman" badge. An Airman draft reopens in the Airman form.
- **Customers** and **Customer History** get an **Airman** tab beside Officer. Airman customers show Orders only (no Spent, no Due).
- **Settings** gets the three lists in section 8.
- The starter item **MODC Uniform** (no price) is added to the item list. It is only available on Airman orders.
- Officer order forms never show MODC Uniform, and Airman forms show every item **without prices**.

## 4. Airman Orders screen

### 4.1 Uniform cards (top)

Six cards: **Battle Uniform**, **Half Sleeve**, **Full Sleeve**, **Summer Ceremonial**, **Winter Ceremonial**, **MODC Uniform**.

- Each shows the **total quantity** ordered of that item for the selected Running Year. "Half Sleeve" counts the item "Half Sleeve Shirt" and "Full Sleeve" counts "Full Sleeve Shirt".
- Tapping a card filters the list to orders that contain that item. A chip such as "Filter: Battle Uniform ✕" clears it.

### 4.2 List area

- A **Running Year** dropdown (for example 2026–2027), defaulting to the newest year in Settings.
- A search box: name, phone, BD number, order number or **IV-Number**.
- Tabs: **All**, **Pending**, **Cutting Slip – Done**, **Delivered**, with counts. A sort dropdown: Newest first, Oldest first.
- Order cards show: order number, "Airman" badge, name (or "Airman" plus the BD number if the name is blank), the status dropdown, BD number, trade, a short items summary with quantities, running year, and the icons **Cutting Slip**, **Edit**, **Delete**. No money anywhere.
- Empty and loading states like the Officer screen.

## 5. New / Edit Airman Order form

Fields in this order:

1. **Items:** a dropdown of items (no prices), a quantity box, and an **IV-Number** box beside it, then **Add Item**. Many items per order; each shows name, quantity, IV-Number and a remove button.
2. **Shirt** and **Pant** measurement boxes, exactly as in Loop 1.
3. **BD Number**, **Name** (can be left blank), **Phone** (can be left blank).
4. **Trade**, **Ribbon**, **Office** (dropdowns).
5. **Running Year** (dropdown) with an **Add Year** button to add a new year to the list.
6. Buttons: **Cancel**, **Save Order** (**Update Order** when editing), **Save as Draft**, **Cutting Slip**. No Print Invoice.

**Saving rules**

- To save: a **BD number**, at least **one item**, and an **IV-Number on every item**. Otherwise show a clear message naming what is missing.
- **IV-Number rule:** an IV-Number belongs to one person. If it is already used on an Airman order of a **different BD number**, do not save and show: "IV-Number X already belongs to BD Y." The same person may repeat an IV-Number across their own items and orders.
- A new BD number creates a new **Airman** customer. An existing BD number uses the saved name, as in Loop 5.
- The order gets the next number in the **Airman** sequence (1, 2, 3 …).
- Order Date is today by default and shown on the order. There is no Delivery Date field.
- Status, Delivery, delete and number-closing behave as for Officer orders, inside the Airman sequence only. Delete keeps its two confirmation steps.
- Drafts follow Loop 4: a BD number and one item are enough to save a draft; the IV-Number is checked only when the draft is finished. Local autosave works the same way.

## 6. Order Details (Airman)

Header (order number, "Airman" badge, name, status), customer info, trade, ribbon, office, running year, order date, items with quantity and IV-Number, measurements and notes. Bottom buttons: **Print Slip** and **Edit Order**. No payment section.

## 7. Cutting slip (Airman)

Same layout rules as Loop 3, with these differences: the title shows "Airman", each item line also shows its **IV-Number**, trade and office appear in the header, and there is no delivery date. No prices. Airman orders have no invoice.

## 8. Settings additions

- **Trade** list (starts empty, editable).
- **Office** list (starts empty, editable).
- **Running Years** list (starts with the current year in the form 2026–2027; **Add Year** on the form adds to it).
- The **Ribbon** list from Loop 1 is shared with Airman orders.

## 9. Delivery screen (Airman tab)

Same as the Officer tab: orders not yet Delivered, search, a **Deliver** button that sets Delivered with today’s date. No Due and no Pay.

## 10. User flows

**A. Yearly batch order.** New Airman Order → add Battle Uniform, quantity 2, IV-Number 5521 → add Uniform Pant, quantity 2, IV-Number 5521 → measurements → BD number, trade, office, ribbon, running year → Save → Airman order #1.

**B. Same person, later.** Another order with the same BD number reuses the saved name; the same IV-Number may repeat.

**C. Wrong IV-Number.** Save with an IV-Number already owned by another BD number → refused with the message → fix → save.

**D. How many uniforms this year?** Airman Orders → pick the Running Year → read the six cards.

**E. Deliver in bulk.** Delivery → Airman tab → search the BD number → Deliver.

**F. Unfinished.** Save as Draft → Drafts shows an "Airman" draft → finish later.

**G. Print for the tailor.** Cutting Slip icon → slip shows items with quantities and IV-Numbers, no prices.

## 11. Not in this loop (do not build)

Invoice for Airmen, prices or payments for Airmen, delivery dates on Airman orders, promoting an Airman to Officer, Export, Dashboard, Bangla, dark mode, install as an app, login, Branch, staff pages, notifications.

## 12. Choices I made, to confirm

1. Airman cards count **total quantity** per item for the selected Running Year.
2. Search also finds by IV-Number.
3. The IV-Number is required on **every item**, not once per order.
4. IV-Number conflicts are only checked against **other BD numbers**.
5. Airman orders have no delivery date.
6. The Running Year dropdown defaults to the newest year.

## 13. Done checklist (test in this order)

1. New Airman Order with nothing filled in: a clear message, nothing saved.
2. Add two items with the same IV-Number for one BD number and save: Airman order #1, with no prices anywhere.
3. Try an item with no IV-Number: refused. Try an IV-Number already used by another BD number: refused with the message. Reuse it for the **same** BD number: allowed.
4. Officer order numbers are untouched. Airman and Officer lists, customers and counters do not mix.
5. The six cards show the right quantities. Change the Running Year and see them change. Tap a card to filter.
6. Search by BD number and by IV-Number each find the right order. Tabs and sort work.
7. Change the status of an Airman order through all three steps.
8. Delivery screen → Airman tab → Deliver an order.
9. The cutting slip shows items, quantities and IV-Numbers, trade and office, and no prices.
10. Save an Airman draft with a BD number and one item (no IV-Number). It appears in Drafts with an Airman badge. Finish it: the IV-Number is now required.
11. Customers → Airman tab shows the new Airman customer with an order count and no money.
12. Delete an Airman order with both confirmations: later Airman numbers close the gap and Officer numbers are unchanged.
13. The word "optional" appears nowhere.
