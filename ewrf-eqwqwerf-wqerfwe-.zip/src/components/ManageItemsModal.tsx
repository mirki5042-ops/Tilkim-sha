import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { ItemDefinition, AirmanItemDefinition, WorkItemDefinition } from '../types/index.ts';
import { STARTER_ITEMS, STARTER_AIRMAN_ITEMS } from '../utils/starterData.ts';
import {
  X,
  Search,
  Plus,
  Trash2,
  Check,
  Tag,
  DollarSign,
  AlertCircle,
  Scissors,
  Layers,
  RotateCcw,
  Sparkles,
} from 'lucide-react';

interface ManageItemsModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialTab?: 'officer' | 'airman' | 'worker';
  onPriceChange?: () => void;
}

const CATEGORIES = ['Uniform', 'Shirt', 'Pant', 'Ceremonial', 'Civil', 'Meskit', 'Other'];

export const ManageItemsModal: React.FC<ManageItemsModalProps> = ({
  isOpen,
  onClose,
  initialTab = 'officer',
  onPriceChange,
}) => {
  const {
    state,
    updateSettings,
    addOfficerItem,
    updateOfficerItem,
    deleteOfficerItem,
    addAirmanItem,
    updateAirmanItem,
    deleteAirmanItem,
    addWorkerItem,
    updateWorkerItem,
    deleteWorkerItem,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'officer' | 'airman' | 'worker'>(initialTab);
  const [searchQuery, setSearchQuery] = useState('');
  const [saveSuccessNotice, setSaveSuccessNotice] = useState<string>('');

  // Add Item local states
  const [newItemName, setNewItemName] = useState('');
  const [newItemPrice, setNewItemPrice] = useState<number | ''>('');
  const [newItemCategory, setNewItemCategory] = useState<string>('Uniform');
  const [formError, setFormError] = useState<string>('');

  // Editable price cache for instantaneous local updates
  const [priceOverrides, setPriceOverrides] = useState<Record<string, number>>({});

  if (!isOpen) return null;

  const showNotice = (msg: string) => {
    setSaveSuccessNotice(msg);
    if (onPriceChange) onPriceChange();
    setTimeout(() => {
      setSaveSuccessNotice('');
    }, 2800);
  };

  // Filtered Officer Items
  const filteredOfficerItems = state.settings.items.filter((item) =>
    item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (item.category && item.category.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  // Filtered Airman Items
  const filteredAirmanItems = state.settings.airmanItems.filter((item) =>
    item.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Filtered Worker Rates
  const filteredWorkItems = state.settings.workItems.filter((item) =>
    item.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handlePriceBlur = (item: ItemDefinition, newPriceVal: number) => {
    if (newPriceVal !== item.price && !isNaN(newPriceVal)) {
      updateOfficerItem(item.id, item.name, newPriceVal, item.category);
      showNotice(`Updated ${item.name} price to ৳${newPriceVal}`);
    }
  };

  const handleAddNewOfficerItem = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');
    if (!newItemName.trim()) {
      setFormError('Please enter an item name');
      return;
    }
    const price = Number(newItemPrice) || 0;
    const res = addOfficerItem(newItemName.trim(), price, newItemCategory);
    if (res.success) {
      showNotice(`Added "${newItemName.trim()}" (৳${price}) to catalog`);
      setNewItemName('');
      setNewItemPrice('');
    } else {
      setFormError(res.error || 'Failed to add item');
    }
  };

  const handleAddNewAirmanItem = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');
    if (!newItemName.trim()) {
      setFormError('Please enter an item name');
      return;
    }
    const res = addAirmanItem(newItemName.trim());
    if (res.success) {
      showNotice(`Added "${newItemName.trim()}" to Airman uniforms`);
      setNewItemName('');
    } else {
      setFormError(res.error || 'Failed to add item');
    }
  };

  const handleResetOfficerDefaults = () => {
    if (window.confirm('Reset Officer items list and default prices to Raymond starter catalog?')) {
      updateSettings({ items: STARTER_ITEMS });
      showNotice('Reset Officer catalog to defaults');
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/60 backdrop-blur-sm animate-in fade-in duration-150"
      onClick={onClose}
    >
      <div
        className="w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh] animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="px-5 sm:px-6 py-4.5 border-b border-[#2A2A2A] bg-[#1A1A1A] text-white flex items-center justify-between shrink-0">
          <div className="flex items-center space-x-3">
            <div className="w-9 h-9 rounded-xl bg-[#2A2A2A] border border-[#3E3E3E] flex items-center justify-center text-white">
              <Scissors className="w-5 h-5 -rotate-45" />
            </div>
            <div>
              <h3 className="font-bold text-base sm:text-lg text-white leading-snug">
                Manage Items & Prices
              </h3>
              <p className="text-xs text-[#A0A0A0]">
                Quickly adjust catalog prices, add new attire, or manage stitching rates
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl text-[#B5B5B5] hover:text-white hover:bg-[#303030] transition-colors cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Success Toast */}
        {saveSuccessNotice && (
          <div className="bg-emerald-50 border-b border-emerald-200 px-5 py-2.5 flex items-center gap-2 text-emerald-800 text-xs font-semibold animate-in slide-in-from-top duration-150">
            <Check className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{saveSuccessNotice}</span>
          </div>
        )}

        {/* Tabs Bar & Search */}
        <div className="p-4 sm:px-6 border-b border-slate-200 bg-slate-50 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 shrink-0">
          {/* Tabs */}
          <div className="flex items-center bg-slate-200/80 p-1 rounded-xl shrink-0">
            <button
              type="button"
              onClick={() => setActiveTab('officer')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'officer'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Officer Attire ({state.settings.items.length})
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('airman')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'airman'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Airman Items ({state.settings.airmanItems.length})
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('worker')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'worker'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Tailor Rates
            </button>
          </div>

          {/* Search Filter */}
          <div className="relative flex-1 max-w-xs">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search items or categories..."
              className="w-full h-8 pl-8 pr-7 text-xs bg-white border border-slate-300 rounded-xl text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700"
              >
                <X className="w-3 h-3" />
              </button>
            )}
          </div>
        </div>

        {/* Scrollable Content Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
          {formError && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-xs font-semibold text-red-700 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{formError}</span>
            </div>
          )}

          {/* OFFICER TAB */}
          {activeTab === 'officer' && (
            <div className="space-y-4">
              {/* Add New Item Strip */}
              <form
                onSubmit={handleAddNewOfficerItem}
                className="p-3.5 bg-blue-50/70 border border-blue-200/70 rounded-2xl flex flex-wrap sm:flex-nowrap items-center gap-2.5"
              >
                <div className="flex-1 min-w-[150px]">
                  <input
                    type="text"
                    value={newItemName}
                    onChange={(e) => setNewItemName(e.target.value)}
                    placeholder="New item name (e.g. Waistcoat)"
                    className="w-full h-9 px-3 rounded-xl bg-white border border-blue-300/80 text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 font-medium"
                  />
                </div>
                <div className="w-28 shrink-0">
                  <select
                    value={newItemCategory}
                    onChange={(e) => setNewItemCategory(e.target.value)}
                    className="w-full h-9 px-2 rounded-xl bg-white border border-blue-300/80 text-xs text-slate-800 font-medium focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer"
                  >
                    {CATEGORIES.map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="w-24 shrink-0 relative">
                  <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-xs font-bold text-blue-600">
                    ৳
                  </span>
                  <input
                    type="number"
                    min="0"
                    step="50"
                    value={newItemPrice}
                    onChange={(e) => setNewItemPrice(e.target.value === '' ? '' : Number(e.target.value))}
                    placeholder="Price"
                    className="w-full h-9 pl-6 pr-2 rounded-xl bg-white border border-blue-300/80 text-xs font-mono font-bold text-blue-700 text-right focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <button
                  type="submit"
                  className="h-9 px-3.5 bg-blue-600 hover:bg-blue-700 active:scale-95 text-white rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 shrink-0 shadow-xs cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
                  <span>Add Item</span>
                </button>
              </form>

              {/* Items List Table */}
              <div className="rounded-2xl border border-slate-200 overflow-hidden divide-y divide-slate-100 bg-white">
                <div className="bg-slate-50 px-4 py-2 text-[11px] font-bold uppercase tracking-wider text-slate-500 flex items-center justify-between">
                  <span>Item Name & Category</span>
                  <span className="pr-12">Price (Taka)</span>
                </div>

                {filteredOfficerItems.map((item) => {
                  const currentDisplayPrice =
                    priceOverrides[item.id] !== undefined ? priceOverrides[item.id] : item.price;

                  return (
                    <div
                      key={item.id}
                      className="px-4 py-2.5 flex items-center justify-between gap-3 hover:bg-slate-50/80 transition-colors group"
                    >
                      <div className="flex-1 min-w-0">
                        <div className="font-semibold text-xs text-slate-900 truncate">
                          {item.name}
                        </div>
                        <div className="text-[10px] text-slate-500 mt-0.5 flex items-center gap-1.5">
                          <span className="px-1.5 py-0.2 rounded bg-slate-100 text-slate-600 font-medium">
                            {item.category || 'Uniform'}
                          </span>
                        </div>
                      </div>

                      {/* Direct Price Edit Input */}
                      <div className="flex items-center space-x-2 shrink-0">
                        <div className="relative w-28">
                          <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-xs font-bold text-blue-600">
                            ৳
                          </span>
                          <input
                            type="number"
                            min="0"
                            step="50"
                            value={currentDisplayPrice}
                            onChange={(e) => {
                              const val = Number(e.target.value);
                              setPriceOverrides({ ...priceOverrides, [item.id]: val });
                            }}
                            onBlur={() => handlePriceBlur(item, currentDisplayPrice)}
                            className="w-full h-8 pl-6 pr-2 rounded-lg border border-slate-300 hover:border-blue-400 focus:border-blue-600 text-xs font-mono font-bold text-slate-900 text-right focus:outline-none focus:ring-1 focus:ring-blue-600 transition-colors"
                          />
                        </div>

                        {/* Delete Button */}
                        <button
                          type="button"
                          onClick={() => {
                            if (window.confirm(`Delete "${item.name}" from catalog?`)) {
                              deleteOfficerItem(item.id);
                              showNotice(`Deleted "${item.name}"`);
                            }
                          }}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-red-600 hover:bg-red-50 transition-colors cursor-pointer"
                          title="Delete item"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })}

                {filteredOfficerItems.length === 0 && (
                  <div className="py-8 text-center text-xs text-slate-400">
                    No officer items found matching "{searchQuery}"
                  </div>
                )}
              </div>
            </div>
          )}

          {/* AIRMAN TAB */}
          {activeTab === 'airman' && (
            <div className="space-y-4">
              {/* Add Airman Item */}
              <form
                onSubmit={handleAddNewAirmanItem}
                className="p-3.5 bg-blue-50/70 border border-blue-200/70 rounded-2xl flex items-center gap-2.5"
              >
                <input
                  type="text"
                  value={newItemName}
                  onChange={(e) => setNewItemName(e.target.value)}
                  placeholder="New Airman item (e.g. Battle Uniform)"
                  className="flex-1 h-9 px-3 rounded-xl bg-white border border-blue-300/80 text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 font-medium"
                />
                <button
                  type="submit"
                  className="h-9 px-4 bg-blue-600 hover:bg-blue-700 active:scale-95 text-white rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 shrink-0 shadow-xs cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
                  <span>Add Airman Item</span>
                </button>
              </form>

              {/* Airman Items List */}
              <div className="rounded-2xl border border-slate-200 overflow-hidden divide-y divide-slate-100 bg-white">
                {filteredAirmanItems.map((item) => (
                  <div
                    key={item.id}
                    className="px-4 py-2.5 flex items-center justify-between gap-3 hover:bg-slate-50 transition-colors"
                  >
                    <span className="font-semibold text-xs text-slate-900">{item.name}</span>
                    <button
                      type="button"
                      onClick={() => {
                        if (window.confirm(`Delete "${item.name}" from Airman uniforms?`)) {
                          deleteAirmanItem(item.id);
                          showNotice(`Deleted "${item.name}"`);
                        }
                      }}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-red-600 hover:bg-red-50 transition-colors cursor-pointer"
                      title="Delete item"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* WORKER TAB */}
          {activeTab === 'worker' && (
            <div className="space-y-4">
              <div className="p-3 bg-slate-100 rounded-xl text-xs text-slate-600 flex items-center justify-between">
                <span>Piece-rate wages paid to tailor staff for stitching each item</span>
                <span className="font-bold text-slate-800">{state.settings.workItems.length} tasks</span>
              </div>

              <div className="rounded-2xl border border-slate-200 overflow-hidden divide-y divide-slate-100 bg-white">
                {filteredWorkItems.map((item) => (
                  <div
                    key={item.id}
                    className="px-4 py-2.5 flex items-center justify-between gap-3 hover:bg-slate-50 transition-colors"
                  >
                    <span className="font-semibold text-xs text-slate-900 truncate">
                      {item.name}
                    </span>
                    <div className="flex items-center space-x-2 shrink-0">
                      <div className="relative w-24">
                        <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-500">
                          ৳
                        </span>
                        <input
                          type="number"
                          min="0"
                          step="5"
                          defaultValue={item.rate}
                          onBlur={(e) => {
                            const val = Number(e.target.value);
                            if (val !== item.rate && !isNaN(val)) {
                              updateWorkerItem(item.id, item.name, val);
                              showNotice(`Updated ${item.name} rate to ৳${val}`);
                            }
                          }}
                          className="w-full h-8 pl-6 pr-2 rounded-lg border border-slate-300 hover:border-slate-400 focus:border-blue-600 text-xs font-mono font-bold text-slate-900 text-right focus:outline-none focus:ring-1 focus:ring-blue-600"
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-5 sm:px-6 py-3.5 border-t border-slate-100 bg-slate-50 flex items-center justify-between shrink-0">
          <div>
            {activeTab === 'officer' && (
              <button
                type="button"
                onClick={handleResetOfficerDefaults}
                className="text-[11px] font-semibold text-slate-500 hover:text-slate-800 flex items-center gap-1 cursor-pointer"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Reset Officer Defaults</span>
              </button>
            )}
          </div>
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold shadow-xs active:scale-95 transition-all cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
