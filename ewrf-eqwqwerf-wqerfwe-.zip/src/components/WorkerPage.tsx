import React, { useState, useEffect, useMemo } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { WorkerEntryRow, WorkItemDefinition } from '../types/index.ts';
import {
  formatDate,
  formatMonth,
  calculateWorkerMonthHishab,
} from '../utils/logic.ts';
import { MONTH_METADATA, MonthMeta } from '../utils/starterData.ts';
import { exportWorkerMonthPDF, exportWorkerPayslipPDF } from '../utils/pdfGenerator.ts';
import {
  ArrowLeft,
  RotateCw,
  Download,
  Printer,
  Plus,
  Trash2,
  Save,
  Search,
  Check,
  AlertTriangle,
  X,
  ChevronDown,
  ChevronUp,
  Settings as SettingsIcon,
  Globe,
  Snowflake,
  Heart,
  Sprout,
  CloudRain,
  Flower2,
  Sun,
  CloudLightning,
  Umbrella,
  Wheat,
  Moon,
  Wind,
  Gift,
  FileText,
} from 'lucide-react';
import { ScreenName } from './Navbar.tsx';

interface WorkerPageProps {
  workerId: string;
  initialMonth?: string;
  onNavigate: (screen: ScreenName, params?: any) => void;
}

const MonthSymbolIcon: React.FC<{ symbol: string; className?: string }> = ({ symbol, className }) => {
  switch (symbol) {
    case 'Snowflake':
      return <Snowflake className={className} />;
    case 'Heart':
      return <Heart className={className} />;
    case 'Sprout':
      return <Sprout className={className} />;
    case 'CloudRain':
      return <CloudRain className={className} />;
    case 'Flower2':
      return <Flower2 className={className} />;
    case 'Sun':
      return <Sun className={className} />;
    case 'CloudLightning':
      return <CloudLightning className={className} />;
    case 'Umbrella':
      return <Umbrella className={className} />;
    case 'Wheat':
      return <Wheat className={className} />;
    case 'Moon':
      return <Moon className={className} />;
    case 'Wind':
      return <Wind className={className} />;
    case 'Gift':
      return <Gift className={className} />;
    default:
      return <FileText className={className} />;
  }
};

export const WorkerPage: React.FC<WorkerPageProps> = ({
  workerId,
  initialMonth,
  onNavigate,
}) => {
  const { state, saveWorkerRows } = useApp();

  const worker = state.workers.find((w) => w.id === workerId);
  const runningMonth = formatMonth();
  const [selectedMonth, setSelectedMonth] = useState(initialMonth || runningMonth);
  const [lang, setLang] = useState<'EN' | 'BN'>('EN');

  const [searchFilter, setSearchFilter] = useState('');
  const [toastMessage, setToastMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [isDirty, setIsDirty] = useState(false);
  const [cancelModalOpen, setCancelModalOpen] = useState(false);
  const [khorachHistoryOpen, setKhorachHistoryOpen] = useState(false);

  // Month styling (table 4.5)
  const monthMeta = useMemo(() => {
    const monthNum = selectedMonth.slice(5, 7);
    return MONTH_METADATA.find((m) => m.numStr === monthNum) || MONTH_METADATA[0];
  }, [selectedMonth]);

  // Unsaved changes beforeunload handler
  useEffect(() => {
    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
      if (isDirty) {
        e.preventDefault();
        e.returnValue = '';
      }
    };
    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => window.removeEventListener('beforeunload', handleBeforeUnload);
  }, [isDirty]);

  // Rows state
  const [rows, setRows] = useState<WorkerEntryRow[]>([]);

  // Default date for new row in selected month (FIX-12: first day of selected month or today if current month)
  const getDefaultRowDate = () => {
    if (selectedMonth === runningMonth) {
      return formatDate();
    }
    return `${selectedMonth}-01`;
  };

  const createBlankRow = (): WorkerEntryRow => ({
    id: `row-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
    workerId,
    date: getDefaultRowDate(),
    serial: '',
    bdNumber: '',
    name: '',
    item: '',
    quantity: 1,
    unitPrice: 0,
    totalTaka: 0,
    khorochDate: '',
    khoroch: 0,
  });

  // Load existing entries followed by 10 blank rows (FIX-12)
  useEffect(() => {
    const existing = state.workerRows.filter((r) => {
      if (r.workerId !== workerId) return false;
      const rowMonth = (r.date || '').slice(0, 7);
      const khorochMonth = (r.khorochDate || r.date || '').slice(0, 7);
      return rowMonth === selectedMonth || khorochMonth === selectedMonth;
    });

    const blankTen = Array.from({ length: 10 }, () => createBlankRow());
    setRows([...existing, ...blankTen]);
    setIsDirty(false);
  }, [workerId, selectedMonth]);

  const handleRowChange = (index: number, field: keyof WorkerEntryRow, value: any) => {
    const updated = [...rows];
    (updated[index] as any)[field] = value;

    if (field === 'quantity' || field === 'unitPrice') {
      const q = Number(field === 'quantity' ? value : updated[index].quantity) || 0;
      const p = Number(field === 'unitPrice' ? value : updated[index].unitPrice) || 0;
      updated[index].totalTaka = q * p;
    }

    setRows(updated);
    setIsDirty(true);
  };

  const handleItemSelect = (index: number, itemName: string) => {
    const updated = [...rows];
    updated[index].item = itemName;

    const workItem = state.settings.workItems.find((w) => w.name === itemName);
    if (workItem) {
      updated[index].unitPrice = workItem.rate;
    }

    const qty = Number(updated[index].quantity) || 1;
    const rate = Number(updated[index].unitPrice) || 0;
    updated[index].totalTaka = qty * rate;

    setRows(updated);
    setIsDirty(true);
  };

  const handleDeleteRow = (index: number) => {
    const updated = rows.filter((_, i) => i !== index);
    setRows(updated);
    setIsDirty(true);
  };

  const handleAdd10Rows = () => {
    const newTen = Array.from({ length: 10 }, () => createBlankRow());
    setRows((prev) => [...prev, ...newTen]);
    setIsDirty(true);
  };

  // Month Hishab calculations for footer
  const hishab = useMemo(() => {
    return calculateWorkerMonthHishab(
      workerId,
      state.workerRows,
      state.workerPayments,
      selectedMonth
    );
  }, [workerId, state.workerRows, state.workerPayments, selectedMonth]);

  // Live footer totals for currently visible rows
  const visibleTotals = useMemo(() => {
    let totalTaka = 0;
    let totalKhoroch = 0;
    for (const r of rows) {
      if (r.item && (r.quantity || 0) > 0) {
        totalTaka += Number(r.totalTaka) || 0;
      }
      if (r.khoroch) {
        totalKhoroch += Number(r.khoroch) || 0;
      }
    }
    return {
      totalTaka,
      totalKhoroch,
      totalPayable: totalTaka - totalKhoroch,
    };
  }, [rows]);

  const handleSave = () => {
    setErrorMessage('');

    // Save only rows that have an item or khoroch
    const res = saveWorkerRows(workerId, rows);
    if (!res.success) {
      setErrorMessage(res.error || 'Failed to save sheet.');
      return;
    }

    setIsDirty(false);
    setToastMessage('Sheet saved successfully.');
    setTimeout(() => setToastMessage(''), 3000);
  };

  const handleRecalculate = () => {
    setRows((prev) =>
      prev.map((r) => ({
        ...r,
        totalTaka: (Number(r.quantity) || 0) * (Number(r.unitPrice) || 0),
      }))
    );
    setToastMessage('Totals recalculated');
    setTimeout(() => setToastMessage(''), 3000);
  };

  const handleDownloadPDF = () => {
    if (!worker) return;
    const validRows = rows.filter((r) => r.item || r.khoroch);
    const workerPayments = state.workerPayments.filter(
      (p) => p.workerId === workerId && p.forMonth === selectedMonth
    );
    if (validRows.length === 0 && workerPayments.length === 0) {
      setToastMessage('Nothing to download for this selection.');
      setTimeout(() => setToastMessage(''), 3000);
      return;
    }
    setToastMessage('Preparing PDF…');
    setTimeout(() => {
      try {
        exportWorkerMonthPDF({
          shopName: state.settings.invoiceShopName || 'Raymond',
          workerName: worker.banglaName ? `${worker.name} (${worker.banglaName})` : worker.name,
          workerPhone: undefined,
          workerRole: 'Tailor',
          month: selectedMonth,
          hishab,
          entries: validRows.map((r) => ({
            date: r.date || '—',
            orderNumber: Number(r.serial) || 0,
            category: r.name ? 'Officer' : 'Airman',
            workItem: r.item || 'Work Item',
            quantity: Number(r.quantity) || 1,
            rate: Number(r.unitPrice) || 0,
            lineTotal: Number(r.totalTaka) || 0,
            notes: r.name ? `Cust: ${r.name}` : undefined,
          })),
          payments: workerPayments.map((p) => ({
            date: p.date,
            amount: p.amount,
            note: p.note,
          })),
        });
        setToastMessage('PDF downloaded');
        setTimeout(() => setToastMessage(''), 3000);
      } catch (err) {
        console.error(err);
        setToastMessage('Failed to generate PDF');
        setTimeout(() => setToastMessage(''), 3000);
      }
    }, 150);
  };

  const handleDownloadPayslipPDF = () => {
    if (!worker) return;
    setToastMessage('Preparing PDF…');
    setTimeout(() => {
      try {
        exportWorkerPayslipPDF({
          shopName: state.settings.invoiceShopName || 'Raymond',
          workerName: worker.banglaName ? `${worker.name} (${worker.banglaName})` : worker.name,
          workerPhone: undefined,
          workerRole: 'Tailor',
          month: selectedMonth,
          hishab,
        });
        setToastMessage('PDF downloaded');
        setTimeout(() => setToastMessage(''), 3000);
      } catch (err) {
        console.error(err);
        setToastMessage('Failed to generate PDF');
        setTimeout(() => setToastMessage(''), 3000);
      }
    }, 150);
  };

  // Khorach History rows (FIX-14)
  const khorachHistoryRows = useMemo(() => {
    const list = rows
      .filter((r) => Number(r.khoroch) > 0)
      .map((r) => ({
        date: r.khorochDate || r.date,
        amount: Number(r.khoroch) || 0,
        note: r.name ? `For: ${r.name}` : r.serial ? `Serial: #${r.serial}` : '',
      }))
      .sort((a, b) => (a.date > b.date ? 1 : -1));

    let running = 0;
    return list.map((item) => {
      running += item.amount;
      return { ...item, runningTotal: running };
    });
  }, [rows]);

  // Filter rows by search term
  const displayedRows = useMemo(() => {
    if (!searchFilter.trim()) return rows;
    const q = searchFilter.toLowerCase().trim();
    return rows.filter((r) => {
      const serialMatch = (r.serial || '').toLowerCase().includes(q);
      const nameMatch = (r.name || '').toLowerCase().includes(q);
      const itemMatch = (r.item || '').toLowerCase().includes(q);
      return serialMatch || nameMatch || itemMatch;
    });
  }, [rows, searchFilter]);

  if (!worker) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-12 text-center text-sm text-gray-500">
        Worker not found.
      </div>
    );
  }

  const handleBackClick = () => {
    if (isDirty) {
      setCancelModalOpen(true);
      return;
    }
    onNavigate('staff-management');
  };

  return (
    <div
      style={{ backgroundColor: monthMeta.tint }}
      className="min-h-screen pb-12 transition-colors duration-300"
    >
      {/* Unsaved Changes Modal (FIX-08) */}
      {cancelModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/40 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl max-w-md w-full p-6 shadow-xl border border-gray-100">
            <h3 className="text-lg font-bold text-gray-900 mb-2">Unsaved Work</h3>
            <p className="text-sm text-gray-600 mb-6">
              You have unsaved changes in this month sheet. Do you want to stay or discard your changes?
            </p>
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setCancelModalOpen(false)}
                className="px-4 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-100 rounded-lg"
              >
                Stay
              </button>
              <button
                type="button"
                onClick={() => {
                  setCancelModalOpen(false);
                  setIsDirty(false);
                  onNavigate('staff-management');
                }}
                className="px-4 py-2 text-sm font-semibold text-red-600 hover:bg-red-50 rounded-lg"
              >
                Leave without saving
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Apple-Style Fluid Gradient Header Band */}
      <div
        className={`text-white px-4 sm:px-6 lg:px-8 py-6 shadow-lg bg-gradient-to-r ${monthMeta.gradient} relative overflow-hidden`}
      >
        <div className="absolute right-0 top-0 bottom-0 opacity-10 pointer-events-none flex items-center pr-12">
          <MonthSymbolIcon symbol={monthMeta.symbol} className="w-48 h-48 transform rotate-12" />
        </div>

        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row sm:items-center sm:justify-between gap-5 relative z-10">
          <div className="flex items-center space-x-4">
            <button
              onClick={handleBackClick}
              className="p-2.5 text-white/90 hover:text-white bg-white/15 hover:bg-white/25 rounded-2xl backdrop-blur-md transition-all active:scale-95"
              aria-label="Back to workers list"
            >
              <ArrowLeft className="w-5 h-5 stroke-[2.5]" />
            </button>
            <div className="flex items-center space-x-3.5">
              <div className="w-12 h-12 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center text-white shrink-0 shadow-inner border border-white/25">
                <MonthSymbolIcon symbol={monthMeta.symbol} className="w-6 h-6 stroke-[2.2]" />
              </div>
              <div>
                <div className="flex items-center space-x-2.5">
                  <h1 className="text-2xl sm:text-3xl font-black tracking-tight">{worker.name}</h1>
                  {worker.banglaName && (
                    <span className="text-base text-white/90 font-bold">({worker.banglaName})</span>
                  )}
                  <span className="text-xs font-mono font-bold px-2 py-0.5 rounded-md bg-white/20 backdrop-blur-xs border border-white/20">
                    #{worker.serialNumber}
                  </span>
                </div>
                <p className="text-xs sm:text-sm text-white/90 font-semibold mt-0.5">
                  {lang === 'BN' ? monthMeta.banglaName : monthMeta.name} {selectedMonth.slice(0, 4)} ·{' '}
                  {lang === 'BN' ? 'মাসিক কাজের খাতা ও খোরচ' : 'Monthly Work Ledger & Khorach'}
                </p>
              </div>
            </div>
          </div>

          {/* Action buttons on top bar */}
          <div className="flex flex-wrap items-center gap-2">
            {/* Language Switch */}
            <button
              onClick={() => setLang(lang === 'EN' ? 'BN' : 'EN')}
              className="px-3 py-2 rounded-xl text-xs font-bold text-white bg-white/15 hover:bg-white/25 backdrop-blur-md border border-white/20 flex items-center space-x-1.5 transition-all active:scale-95 cursor-pointer"
            >
              <Globe className="w-4 h-4" />
              <span>{lang === 'EN' ? 'বাংলা' : 'EN'}</span>
            </button>

            {/* Recalculate */}
            <button
              onClick={handleRecalculate}
              className="px-3.5 py-2 rounded-xl text-xs font-bold text-white bg-white/15 hover:bg-white/25 backdrop-blur-md border border-white/20 flex items-center space-x-1.5 transition-all active:scale-95 cursor-pointer"
            >
              <RotateCw className="w-4 h-4" />
              <span>Recalculate</span>
            </button>

            {/* Download Statement PDF */}
            <button
              onClick={handleDownloadPDF}
              className="px-3.5 py-2 rounded-xl text-xs font-bold text-white bg-white/15 hover:bg-white/25 backdrop-blur-md border border-white/20 flex items-center space-x-1.5 transition-all active:scale-95 cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Download PDF</span>
            </button>

            {/* Download Payslip PDF */}
            <button
              onClick={handleDownloadPayslipPDF}
              className="px-4 py-2 rounded-xl text-xs font-black text-gray-950 bg-white hover:bg-gray-100 flex items-center space-x-1.5 shadow-md transition-all active:scale-95 cursor-pointer"
            >
              <Download className="w-4 h-4 text-gray-900" />
              <span>Download Payslip</span>
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {/* Toast Notification */}
        {toastMessage && (
          <div className="p-4 bg-emerald-50 border-2 border-emerald-400 text-emerald-950 text-sm font-bold rounded-2xl flex items-center justify-between shadow-lg shadow-emerald-500/10 animate-in fade-in">
            <div className="flex items-center space-x-2.5">
              <span className="w-6 h-6 rounded-full bg-emerald-500 text-white flex items-center justify-center font-bold">
                <Check className="w-3.5 h-3.5 stroke-[3]" />
              </span>
              <span>{toastMessage}</span>
            </div>
            <button onClick={() => setToastMessage('')} className="text-emerald-900">
              ✕
            </button>
          </div>
        )}

        {/* Error Message */}
        {errorMessage && (
          <div className="p-4 bg-red-50 border-2 border-red-300 text-red-900 text-sm font-bold rounded-2xl flex items-center justify-between shadow-lg shadow-red-500/10">
            <span>{errorMessage}</span>
            <button onClick={() => setErrorMessage('')} className="text-red-900 font-bold">
              ✕
            </button>
          </div>
        )}

        {/* 3 High-Contrast Apple KPI Summary Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="bg-white p-5 rounded-3xl border-2 border-gray-200 shadow-sm flex flex-col justify-between">
            <span className="text-xs font-bold text-gray-500 uppercase tracking-wider">
              {lang === 'BN' ? 'মোট কাজের টাকা' : 'Total Work Earnings'}
            </span>
            <div className="mt-2 flex items-baseline justify-between">
              <span className="text-2xl sm:text-3xl font-black text-gray-950 font-mono tabular-nums">
                ৳{visibleTotals.totalTaka.toLocaleString()}
              </span>
              <span className="text-xs font-bold text-gray-500 bg-gray-100 px-2.5 py-1 rounded-full">
                {rows.filter((r) => r.item && (r.quantity || 0) > 0).length} items
              </span>
            </div>
          </div>

          <div className="bg-white p-5 rounded-3xl border-2 border-amber-300 shadow-sm flex flex-col justify-between bg-gradient-to-br from-amber-50/50 to-white">
            <span className="text-xs font-bold text-amber-800 uppercase tracking-wider">
              {lang === 'BN' ? 'মোট খোরচ (অগ্রিম)' : 'Total Khorach (Advances)'}
            </span>
            <div className="mt-2 flex items-baseline justify-between">
              <span className="text-2xl sm:text-3xl font-black text-amber-900 font-mono tabular-nums">
                ৳{visibleTotals.totalKhoroch.toLocaleString()}
              </span>
              <button
                onClick={() => setKhorachHistoryOpen(!khorachHistoryOpen)}
                className="text-xs font-extrabold text-amber-800 underline hover:text-amber-950"
              >
                {khorachHistoryOpen ? 'Hide Log' : 'View Log'}
              </button>
            </div>
          </div>

          <div className={`p-5 rounded-3xl border-2 shadow-sm flex flex-col justify-between ${
            visibleTotals.totalPayable < 0
              ? 'bg-rose-50 border-rose-300'
              : 'bg-emerald-50/70 border-emerald-400'
          }`}>
            <span className={`text-xs font-bold uppercase tracking-wider ${
              visibleTotals.totalPayable < 0 ? 'text-rose-800' : 'text-emerald-900'
            }`}>
              {lang === 'BN' ? 'মোট প্রদেয় টাকা' : 'Net Month Balance (Payable)'}
            </span>
            <div className="mt-2 flex items-baseline justify-between">
              <span className={`text-2xl sm:text-3xl font-black font-mono tabular-nums ${
                visibleTotals.totalPayable < 0 ? 'text-rose-700' : 'text-emerald-800'
              }`}>
                ৳{visibleTotals.totalPayable.toLocaleString()}
              </span>
              <span className={`text-xs font-extrabold px-2.5 py-1 rounded-full ${
                visibleTotals.totalPayable < 0
                  ? 'bg-rose-200 text-rose-900'
                  : 'bg-emerald-200 text-emerald-950'
              }`}>
                {visibleTotals.totalPayable < 0 ? 'Overpaid' : 'Payable'}
              </span>
            </div>
          </div>
        </div>

        {/* Interactive Month Switcher Carousel */}
        <div className="bg-white p-4 rounded-3xl border-2 border-gray-200 shadow-sm space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center space-x-2 overflow-x-auto py-1">
              {MONTH_METADATA.map((m) => {
                const yearPrefix = selectedMonth.slice(0, 4);
                const targetMonth = `${yearPrefix}-${m.numStr}`;
                const isActive = selectedMonth === targetMonth;

                return (
                  <button
                    key={m.numStr}
                    onClick={() => setSelectedMonth(targetMonth)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center space-x-1.5 active:scale-95 cursor-pointer ${
                      isActive
                        ? `bg-gradient-to-r ${m.gradient} text-white shadow-md shadow-black/10 scale-105`
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    <span>{lang === 'BN' ? m.banglaName : m.name.slice(0, 3)}</span>
                  </button>
                );
              })}
            </div>

            <div className="flex items-center space-x-2 shrink-0">
              <input
                type="month"
                value={selectedMonth}
                onChange={(e) => {
                  if (e.target.value) setSelectedMonth(e.target.value);
                }}
                className="px-3 py-1.5 text-xs font-bold border-2 border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500"
              />
              <div className="relative w-48">
                <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  placeholder="Filter entries..."
                  value={searchFilter}
                  onChange={(e) => setSearchFilter(e.target.value)}
                  className="w-full pl-8 pr-2.5 py-1.5 text-xs border-2 border-gray-200 rounded-xl focus:border-blue-500"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Entry List Card (FIX-12) */}
        <div className="bg-white rounded-3xl border-2 border-gray-200 shadow-sm overflow-hidden">
          <div className="p-4 sm:p-5 border-b border-gray-200 flex flex-wrap items-center justify-between gap-3 bg-gray-50/70">
            <div className="flex items-center space-x-3">
              <h2 className="text-base font-black text-gray-950 uppercase tracking-wider">Work Ledger</h2>
              <span className="text-xs font-bold text-gray-500 bg-gray-200 px-2.5 py-0.5 rounded-full">
                {rows.length} rows
              </span>
              {isDirty && (
                <span className="px-2.5 py-0.5 rounded-full text-xs font-extrabold bg-amber-100 text-amber-900 border border-amber-300 animate-pulse">
                  Unsaved changes
                </span>
              )}
            </div>
            <div className="flex items-center space-x-2">
              <button
                type="button"
                onClick={handleAdd10Rows}
                className="px-3.5 py-2 border-2 border-gray-200 rounded-xl text-xs font-bold text-gray-800 bg-white hover:bg-gray-50 shadow-xs active:scale-95 cursor-pointer"
              >
                + Add 10 Rows
              </button>
              <button
                type="button"
                onClick={handleSave}
                className={`px-5 py-2 text-white rounded-xl text-xs font-black shadow-md flex items-center space-x-1.5 hover:opacity-95 active:scale-95 bg-gradient-to-r ${monthMeta.gradient} cursor-pointer`}
              >
                <Save className="w-4 h-4" />
                <span>Save Sheet</span>
              </button>
            </div>
          </div>


          {/* Month Entry Table (10 columns in exact order + delete icon) */}
          <div className="overflow-x-auto max-h-[600px] overflow-y-auto">
            <table className="min-w-full divide-y divide-gray-200 text-xs">
              <thead
                className={`text-white font-black sticky top-0 z-10 bg-gradient-to-r ${monthMeta.gradient} shadow-sm`}
              >
                <tr>
                  <th className="px-2.5 py-2.5 text-left w-28">Date</th>
                  <th className="px-2.5 py-2.5 text-left w-20">Serial</th>
                  <th className="px-2.5 py-2.5 text-left w-32">Name</th>
                  <th className="px-2.5 py-2.5 text-left w-48">Item</th>
                  <th className="px-2 py-2.5 text-center w-16">Quantity</th>
                  <th className="px-2 py-2.5 text-right w-20">Unit Price</th>
                  <th className="px-3 py-2.5 text-right w-24">Total Taka</th>
                  <th className="px-2.5 py-2.5 text-left w-28">Khorach Date</th>
                  <th className="px-2.5 py-2.5 text-right w-24">Khorach</th>
                  <th className="px-3 py-2.5 text-right w-24">Total Payable</th>
                  <th className="px-2 py-2.5 text-center w-10"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 bg-white">
                {displayedRows.map((row, idx) => {
                  const rowPayable = (Number(row.totalTaka) || 0) - (Number(row.khoroch) || 0);

                  return (
                    <tr key={row.id || idx} className="hover:bg-blue-50/30">
                      {/* 1. Date */}
                      <td className="px-2 py-1.5">
                        <input
                          type="date"
                          value={row.date}
                          onChange={(e) => handleRowChange(idx, 'date', e.target.value)}
                          className="w-full px-1.5 py-1 text-xs border border-gray-300 rounded focus:ring-1 focus:ring-blue-500 font-medium"
                        />
                      </td>

                      {/* 2. Serial (free text) */}
                      <td className="px-2 py-1.5">
                        <input
                          type="text"
                          value={row.serial}
                          onChange={(e) => handleRowChange(idx, 'serial', e.target.value)}
                          placeholder="e.g. 521"
                          className="w-full px-1.5 py-1 text-xs border border-gray-300 rounded focus:ring-1 focus:ring-blue-500 font-medium"
                        />
                      </td>

                      {/* 3. Name (free text) */}
                      <td className="px-2 py-1.5">
                        <input
                          type="text"
                          value={row.name}
                          onChange={(e) => handleRowChange(idx, 'name', e.target.value)}
                          placeholder="Customer name"
                          className="w-full px-1.5 py-1 text-xs border border-gray-300 rounded font-medium"
                        />
                      </td>

                      {/* 4. Item (Worker Items with prices & Manage Items link) */}
                      <td className="px-2 py-1.5">
                        <select
                          value={row.item}
                          onChange={(e) => {
                            if (e.target.value === '__manage__') {
                              onNavigate('settings');
                            } else {
                              handleItemSelect(idx, e.target.value);
                            }
                          }}
                          className="w-full px-1.5 py-1 text-xs border border-gray-300 rounded focus:ring-1 focus:ring-blue-500 font-medium"
                        >
                          <option value="">-- Choose item --</option>
                          {state.settings.workItems.map((wi) => (
                            <option key={wi.id} value={wi.name}>
                              {wi.name} — ৳{wi.rate}
                            </option>
                          ))}
                          <option value="__manage__" className="font-bold text-blue-600">
                            ⚙ Manage Items...
                          </option>
                        </select>
                      </td>

                      {/* 5. Quantity */}
                      <td className="px-2 py-1.5 text-center">
                        <input
                          type="number"
                          inputMode="numeric"
                          min="1"
                          value={row.quantity}
                          onChange={(e) =>
                            handleRowChange(idx, 'quantity', parseInt(e.target.value, 10) || 0)
                          }
                          className="w-14 px-1.5 py-1 text-xs text-center border border-gray-300 rounded font-medium"
                        />
                      </td>

                      {/* 6. Unit Price (stays editable) */}
                      <td className="px-2 py-1.5 text-right">
                        <input
                          type="number"
                          inputMode="numeric"
                          min="0"
                          value={row.unitPrice}
                          onChange={(e) =>
                            handleRowChange(idx, 'unitPrice', parseFloat(e.target.value) || 0)
                          }
                          className="w-16 px-1.5 py-1 text-xs text-right border border-gray-300 rounded font-medium"
                        />
                      </td>

                      {/* 7. Total Taka */}
                      <td className="px-3 py-1.5 text-right font-bold text-gray-900">
                        ৳{row.totalTaka}
                      </td>

                      {/* 8. Khorach Date (starts blank) */}
                      <td className="px-2 py-1.5">
                        <input
                          type="date"
                          value={row.khorochDate || ''}
                          onChange={(e) => handleRowChange(idx, 'khorochDate', e.target.value)}
                          className="w-full px-1.5 py-1 text-xs border border-gray-300 rounded font-medium"
                        />
                      </td>

                      {/* 9. Khorach */}
                      <td className="px-2 py-1.5 text-right">
                        <input
                          type="number"
                          inputMode="numeric"
                          min="0"
                          value={row.khoroch || 0}
                          onChange={(e) =>
                            handleRowChange(idx, 'khoroch', parseFloat(e.target.value) || 0)
                          }
                          className="w-20 px-1.5 py-1 text-xs text-right border border-gray-300 rounded text-amber-800 font-semibold"
                        />
                      </td>

                      {/* 10. Total Payable */}
                      <td
                        className={`px-3 py-1.5 text-right font-bold ${
                          rowPayable < 0 ? 'text-red-600' : 'text-gray-900'
                        }`}
                      >
                        ৳{rowPayable}
                      </td>

                      {/* 11. Delete Row */}
                      <td className="px-2 py-1.5 text-center">
                        <button
                          type="button"
                          onClick={() => handleDeleteRow(idx)}
                          className="text-gray-300 hover:text-red-600 p-0.5"
                          title="Delete row"
                          aria-label={`Delete row ${idx + 1}`}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Footer: Total (taka), Total Khorach, Total Payable for visible month (FIX-12) */}
          <div className="bg-gray-50 border-t border-gray-200 p-4 grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs font-bold text-center">
            <div className="bg-white p-3 rounded-lg border border-gray-200 shadow-2xs">
              <span className="text-gray-500 block text-[11px] uppercase tracking-wider">
                Total (Taka)
              </span>
              <span className="text-base text-gray-900 font-extrabold">
                ৳{visibleTotals.totalTaka.toLocaleString()}
              </span>
            </div>
            <div className="bg-white p-3 rounded-lg border border-gray-200 shadow-2xs">
              <span className="text-gray-500 block text-[11px] uppercase tracking-wider">
                Total Khorach
              </span>
              <span className="text-base text-amber-700 font-extrabold">
                ৳{visibleTotals.totalKhoroch.toLocaleString()}
              </span>
            </div>
            <div className="bg-white p-3 rounded-lg border border-gray-200 shadow-2xs">
              <span className="text-gray-500 block text-[11px] uppercase tracking-wider">
                Total Payable
              </span>
              <span
                className={`text-base font-extrabold ${
                  visibleTotals.totalPayable < 0 ? 'text-red-600' : 'text-emerald-700'
                }`}
              >
                ৳{visibleTotals.totalPayable.toLocaleString()}
              </span>
            </div>
          </div>
        </div>

        {/* Collapsible Khorach History Section (FIX-14) */}
        <div className="bg-white rounded-xl border border-gray-200 shadow-xs overflow-hidden">
          <button
            type="button"
            onClick={() => setKhorachHistoryOpen(!khorachHistoryOpen)}
            className="w-full p-4 flex items-center justify-between bg-gray-50 hover:bg-gray-100/80 text-left transition-colors"
          >
            <div className="flex items-center space-x-2">
              <h3 className="text-sm font-bold text-gray-900">Khorach History</h3>
              <span className="px-2 py-0.5 text-xs font-semibold rounded-full bg-amber-100 text-amber-800">
                {khorachHistoryRows.length} entries
              </span>
            </div>
            <div className="flex items-center space-x-2 text-xs text-gray-500">
              <span>Running Total: ৳{visibleTotals.totalKhoroch.toLocaleString()}</span>
              {khorachHistoryOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </div>
          </button>

          {khorachHistoryOpen && (
            <div className="p-4 border-t border-gray-100">
              {khorachHistoryRows.length > 0 ? (
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200 text-xs">
                    <thead className="bg-gray-50 text-gray-600 font-semibold">
                      <tr>
                        <th className="px-3 py-2 text-left">Date</th>
                        <th className="px-3 py-2 text-left">Details</th>
                        <th className="px-3 py-2 text-right">Khorach Amount</th>
                        <th className="px-3 py-2 text-right">Running Total</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100 bg-white">
                      {khorachHistoryRows.map((entry, i) => (
                        <tr key={i} className="hover:bg-amber-50/30">
                          <td className="px-3 py-2 font-medium text-gray-800">{entry.date}</td>
                          <td className="px-3 py-2 text-gray-600">{entry.note || 'Advance expense'}</td>
                          <td className="px-3 py-2 text-right font-bold text-amber-800">
                            ৳{entry.amount.toLocaleString()}
                          </td>
                          <td className="px-3 py-2 text-right font-extrabold text-gray-900">
                            ৳{entry.runningTotal.toLocaleString()}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="text-center py-6 text-gray-400 text-xs">
                  No Khorach amounts recorded for this month.
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
