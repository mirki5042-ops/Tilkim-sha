import React from 'react';

interface GeniestudioDividerProps {
  label?: string;
  icon?: React.ReactNode;
  variant?: 'subtle' | 'pill' | 'iris';
  className?: string;
}

export const GeniestudioDivider: React.FC<GeniestudioDividerProps> = ({
  label,
  icon,
  variant = 'pill',
  className = '',
}) => {
  if (!label) {
    return (
      <div className={`relative my-6 ${className}`}>
        <div className="h-px bg-gradient-to-r from-transparent via-[#dbeafe] to-transparent" />
      </div>
    );
  }

  return (
    <div className={`relative flex items-center justify-center my-6 select-none ${className}`}>
      {/* Background Divider Line */}
      <div className="absolute inset-0 flex items-center" aria-hidden="true">
        <div className="w-full border-t border-[#dbeafe]" />
      </div>

      {/* Center Pill Badge */}
      <div className="relative flex items-center gap-1.5 px-4 py-1 rounded-full bg-[#fafdff] border border-[#dbeafe] shadow-xs text-xs font-semibold text-[#535862]">
        {variant === 'iris' && (
          <span className="w-2 h-2 rounded-full bg-[#0069e0] animate-pulse" />
        )}
        {icon && <span className="text-[#0069e0]">{icon}</span>}
        <span className="tracking-tight text-[11px] uppercase font-bold text-[#0a0d12]/80">
          {label}
        </span>
      </div>
    </div>
  );
};
