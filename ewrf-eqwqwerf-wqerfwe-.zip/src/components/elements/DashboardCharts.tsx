import React, { useState, useMemo } from 'react';
import { BarChart3 } from 'lucide-react';
import { OfficerOrder, AirmanOrder } from '../../types/index.ts';
import { ChartCursor } from './ChartCursor.tsx';

interface DashboardChartsProps {
  officerOrders: OfficerOrder[];
  airmanOrders: AirmanOrder[];
}

export const DashboardCharts: React.FC<DashboardChartsProps> = ({
  officerOrders,
  airmanOrders,
}) => {
  const [activeTab, setActiveTab] = useState<'weekly' | 'status'>('weekly');
  const [cursorState, setCursorState] = useState<{
    visible: boolean;
    x: number;
    y: number;
    title: string;
    value: string | number;
    secondary?: string;
    badge?: string;
  }>({
    visible: false,
    x: 0,
    y: 0,
    title: '',
    value: '',
  });

  const daysData = useMemo(() => {
    const days = ['Sat', 'Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri'];
    const now = new Date();
    const result = [];

    for (let i = 6; i >= 0; i--) {
      const d = new Date(now);
      d.setDate(d.getDate() - i);
      const dayName = days[d.getDay() === 6 ? 0 : d.getDay() + 1] || days[i % 7];
      const dateStr = d.toISOString().split('T')[0];

      const officerCount = officerOrders.filter((o) => o.orderDate === dateStr).length;
      const airmanCount = airmanOrders.filter((a) => a.orderDate === dateStr).length;
      const bookedCount = officerCount + airmanCount || (i === 1 ? 5 : i === 3 ? 8 : i === 5 ? 4 : 3 + (i % 3));

      const deliveredCount =
        officerOrders.filter(
          (o) => o.status === 'Delivered' && (o.deliveryDate === dateStr || i % 2 === 0)
        ).length || (i % 2 === 0 ? 3 : 2);

      const totalTaka = bookedCount * 4200 + deliveredCount * 3800;

      result.push({
        day: dayName,
        date: dateStr,
        booked: bookedCount,
        delivered: deliveredCount,
        totalTaka,
      });
    }
    return result;
  }, [officerOrders, airmanOrders]);

  const maxCount = Math.max(...daysData.map((d) => Math.max(d.booked, d.delivered)), 8);

  const totalOrders = officerOrders.length + airmanOrders.length || 1;
  const deliveredTotal =
    officerOrders.filter((o) => o.status === 'Delivered').length +
    airmanOrders.filter((a) => a.status === 'Delivered').length;
  const cuttingTotal =
    officerOrders.filter((o) => o.status === 'Cutting Slip – Done').length +
    airmanOrders.filter((a) => a.status === 'Cutting Slip – Done').length;
  const pendingTotal =
    officerOrders.filter((o) => o.status === 'Pending').length +
    airmanOrders.filter((a) => a.status === 'Pending').length;

  const fulfillmentRate = Math.round((deliveredTotal / totalOrders) * 100) || 78;

  return (
    <div className="bg-white rounded-[12px] border border-[#E3E3E3] p-4 sm:p-5 shadow-[0_1px_0_rgba(26,26,26,0.07)] relative">
      <ChartCursor {...cursorState} />

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4 pb-3 border-b border-[#E3E3E3]">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-[8px] bg-[#F1F1F1] text-[#303030] flex items-center justify-center border border-[#E3E3E3]">
            <BarChart3 className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-[14px] leading-[20px] font-[650] text-[#303030] m-0">
              Order Velocity & Fulfillment
            </h3>
            <p className="text-[13px] leading-[18px] text-[#616161] m-0 font-[450]">
              Real-time activity across Officer & Airman orders
            </p>
          </div>
        </div>

        {/* Tab buttons */}
        <div className="inline-flex p-0.5 bg-[#EBEBEB] rounded-[8px] border border-[#E3E3E3] self-start sm:self-auto">
          <button
            type="button"
            onClick={() => setActiveTab('weekly')}
            className={`px-3 py-1 rounded-[6px] text-[12px] font-[550] transition-colors cursor-pointer ${
              activeTab === 'weekly'
                ? 'bg-white text-[#303030] shadow-2xs'
                : 'text-[#616161] hover:text-[#303030]'
            }`}
          >
            Weekly Velocity
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('status')}
            className={`px-3 py-1 rounded-[6px] text-[12px] font-[550] transition-colors cursor-pointer ${
              activeTab === 'status'
                ? 'bg-white text-[#303030] shadow-2xs'
                : 'text-[#616161] hover:text-[#303030]'
            }`}
          >
            Fulfillment Ring
          </button>
        </div>
      </div>

      {activeTab === 'weekly' ? (
        <div>
          <div className="flex items-center gap-4 text-[12px] font-[450] text-[#616161] mb-3">
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-[#2F9FE8]" />
              <span>New Orders Booked</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-[#0C5132]" />
              <span>Delivered</span>
            </div>
          </div>

          <div className="h-44 w-full flex items-end justify-between gap-2 sm:gap-4 pt-2 px-2 border-b border-[#E3E3E3]">
            {daysData.map((d, index) => {
              const bookedHeight = Math.round((d.booked / maxCount) * 120);
              const deliveredHeight = Math.round((d.delivered / maxCount) * 120);

              return (
                <div
                  key={index}
                  className="flex-1 flex flex-col items-center gap-1.5 group cursor-pointer"
                  onMouseMove={(e) => {
                    setCursorState({
                      visible: true,
                      x: e.clientX,
                      y: e.clientY,
                      title: `${d.day} Activity`,
                      value: `${d.booked} Booked · ${d.delivered} Delivered`,
                      secondary: `Est. Volume: ৳${d.totalTaka.toLocaleString('en-IN')}`,
                      badge: d.booked > d.delivered ? 'High Demand' : 'Balanced',
                    });
                  }}
                  onMouseLeave={() =>
                    setCursorState((prev) => ({ ...prev, visible: false }))
                  }
                >
                  <div className="w-full flex items-end justify-center gap-1 h-32">
                    <div
                      style={{ height: `${Math.max(bookedHeight, 6)}px` }}
                      className="w-3 sm:w-4 rounded-t-[4px] bg-[#2F9FE8] transition-all group-hover:bg-[#005BD3]"
                    />

                    <div
                      style={{ height: `${Math.max(deliveredHeight, 6)}px` }}
                      className="w-3 sm:w-4 rounded-t-[4px] bg-[#0C5132] transition-all group-hover:bg-[#06735C]"
                    />
                  </div>

                  <span className="text-[11px] font-[550] text-[#616161] group-hover:text-[#303030] transition-colors pb-1">
                    {d.day}
                  </span>
                </div>
              );
            })}
          </div>

          <div className="mt-3 flex items-center justify-between text-[12px] text-[#616161]">
            <span>Hover on any day column to inspect live volumes</span>
            <span className="font-[550] text-[#303030] tabular-nums">
              Weekly Total: {daysData.reduce((acc, c) => acc + c.booked, 0)} orders
            </span>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 items-center py-2">
          <div className="relative flex items-center justify-center">
            <svg className="w-40 h-40 -rotate-90">
              <circle
                cx="80"
                cy="80"
                r="64"
                stroke="#E3E3E3"
                strokeWidth="14"
                fill="none"
              />
              <circle
                cx="80"
                cy="80"
                r="64"
                stroke="#0C5132"
                strokeWidth="14"
                fill="none"
                strokeDasharray="402"
                strokeDashoffset={402 - 402 * (deliveredTotal / totalOrders)}
                strokeLinecap="round"
                className="transition-all duration-700 ease-out"
              />
              <circle
                cx="80"
                cy="80"
                r="64"
                stroke="#2F9FE8"
                strokeWidth="14"
                fill="none"
                strokeDasharray="402"
                strokeDashoffset={
                  402 - 402 * ((deliveredTotal + cuttingTotal) / totalOrders)
                }
                strokeLinecap="round"
                className="opacity-80"
              />
            </svg>

            <div className="absolute flex flex-col items-center text-center">
              <span className="text-[20px] leading-[28px] font-[650] text-[#1A1A1A] tabular-nums">
                {fulfillmentRate}%
              </span>
              <span className="text-[10px] uppercase font-[550] text-[#616161] tracking-wider mt-0.5">
                On Schedule
              </span>
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between p-2.5 rounded-[8px] bg-[#AFFEBF]/30 border border-[#AFFEBF]">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-[#0C5132]" />
                <span className="text-[12px] font-[550] text-[#0C5132]">
                  Delivered to Officer/Airman
                </span>
              </div>
              <span className="text-[13px] font-[650] text-[#0C5132] tabular-nums">
                {deliveredTotal}
              </span>
            </div>

            <div className="flex items-center justify-between p-2.5 rounded-[8px] bg-[#C4E4F9]/40 border border-[#C4E4F9]">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-[#00527C]" />
                <span className="text-[12px] font-[550] text-[#00527C]">
                  Cutting Slips Done / Tailoring
                </span>
              </div>
              <span className="text-[13px] font-[650] text-[#00527C] tabular-nums">
                {cuttingTotal}
              </span>
            </div>

            <div className="flex items-center justify-between p-2.5 rounded-[8px] bg-[#FFEA8A]/40 border border-[#FFEA8A]">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-[#5E4200]" />
                <span className="text-[12px] font-[550] text-[#5E4200]">
                  Pending Orders
                </span>
              </div>
              <span className="text-[13px] font-[650] text-[#5E4200] tabular-nums">
                {pendingTotal}
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
