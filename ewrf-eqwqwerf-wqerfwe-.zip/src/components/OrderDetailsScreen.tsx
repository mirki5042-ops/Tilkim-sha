import React, { useState } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { StatusBadge } from './StatusBadge.tsx';
import { PolarisPage } from './polaris/PolarisPage.tsx';
import { PolarisCard } from './polaris/PolarisCard.tsx';
import {
  Scissors,
  Printer,
  Edit2,
  Trash2,
  CreditCard,
  X,
  AlertTriangle,
} from 'lucide-react';
import { ScreenName } from './Navbar.tsx';

interface OrderDetailsScreenProps {
  orderNumber: number;
  category: 'Officer' | 'Airman';
  onNavigate: (screen: ScreenName, params?: any) => void;
  fromDelivery?: boolean;
}

export const OrderDetailsScreen: React.FC<OrderDetailsScreenProps> = ({
  orderNumber,
  category,
  onNavigate,
  fromDelivery = false,
}) => {
  const {
    state,
    updateOfficerOrderStatus,
    updateAirmanOrderStatus,
    deleteOfficerOrder,
    deleteAirmanOrder,
    recordOfficerPayment,
  } = useApp();

  const isOfficer = category === 'Officer';
  const officerOrder = isOfficer ? state.officerOrders.find((o) => o.orderNumber === orderNumber) : null;
  const airmanOrder = !isOfficer ? state.airmanOrders.find((o) => o.orderNumber === orderNumber) : null;

  const order = isOfficer ? officerOrder : airmanOrder;

  // Pay Modal
  const [payModalOpen, setPayModalOpen] = useState(false);

  // Delete 2-step modal
  const [deleteStep, setDeleteStep] = useState<0 | 1 | 2>(0);

  const handleBack = () => {
    if (fromDelivery) {
      onNavigate('delivery');
    } else {
      onNavigate(isOfficer ? 'orders' : 'airman-orders');
    }
  };

  if (!order) {
    return (
      <PolarisPage
        title="Order Not Found"
        backAction={handleBack}
      >
        <PolarisCard>
          <div className="p-8 text-center text-[#616161]">
            <p className="text-[13px] mb-4">
              Order #{orderNumber} in {category} does not exist or was moved to Deleted History.
            </p>
            <button
              onClick={handleBack}
              className="h-7 px-3 rounded-lg bg-[#303030] text-white text-[13px] font-[550]"
            >
              Back
            </button>
          </div>
        </PolarisCard>
      </PolarisPage>
    );
  }

  const handleDeleteStep1 = () => setDeleteStep(2);
  const handleDeleteStep2 = () => {
    if (isOfficer) {
      deleteOfficerOrder(orderNumber);
      handleBack();
    } else {
      deleteAirmanOrder(orderNumber);
      handleBack();
    }
  };

  const handlePay = () => {
    if (isOfficer && officerOrder) {
      recordOfficerPayment(orderNumber, officerOrder.due);
      setPayModalOpen(false);
    }
  };

  const displayName = isOfficer
    ? officerOrder?.customerName
    : airmanOrder?.customerName || `Airman ${airmanOrder?.customerBdNumber}`;

  const hasDue = isOfficer && officerOrder && officerOrder.due > 0;
  const canPay = isOfficer && officerOrder && officerOrder.status === 'Delivered' && hasDue;

  return (
    <PolarisPage
      title={`Order #${order.orderNumber}`}
      subtitle={`${category} Order · Customer BD: ${order.customerBdNumber}`}
      backAction={handleBack}
      badge={
        <div className="flex items-center space-x-2">
          <span
            className={`px-2 py-0.5 text-[11px] font-[550] rounded-md ${
              isOfficer ? 'bg-[#EAF4FF] text-[#005BD3]' : 'bg-[#F0EEFF] text-[#5B3DF5]'
            }`}
          >
            {category}
          </span>
          <StatusBadge
            status={order.status}
            interactive={true}
            onChange={(newStatus) => {
              if (newStatus === 'Delivered') {
                onNavigate('confirm-delivery', { orderNumber, category, fromDelivery });
                return;
              }
              if (isOfficer) updateOfficerOrderStatus(orderNumber, newStatus);
              else updateAirmanOrderStatus(orderNumber, newStatus);
            }}
          />
        </div>
      }
      secondaryActions={[
        {
          label: 'Print All Slips',
          onClick: () =>
            onNavigate('print-slip', {
              orderNumber: order.orderNumber,
              category,
            }),
          icon: <Scissors className="w-3.5 h-3.5" />,
        },
        ...(isOfficer
          ? [
              {
                label: 'Invoice',
                onClick: () =>
                  onNavigate('print-invoice', {
                    orderNumber: order.orderNumber,
                    category: 'Officer',
                  }),
                icon: <Printer className="w-3.5 h-3.5" />,
              },
            ]
          : []),
        {
          label: 'Edit',
          onClick: () =>
            onNavigate(isOfficer ? 'edit-officer-order' : 'edit-airman-order', {
              orderNumber: order.orderNumber,
            }),
          icon: <Edit2 className="w-3.5 h-3.5" />,
        },
        {
          label: 'Delete',
          onClick: () => setDeleteStep(1),
          icon: <Trash2 className="w-3.5 h-3.5" />,
        },
      ]}
      primaryAction={
        order.status !== 'Delivered'
          ? {
              label: 'Deliver Order',
              onClick: () =>
                onNavigate('confirm-delivery', { orderNumber, category, fromDelivery }),
            }
          : canPay
          ? {
              label: 'Pay Due',
              onClick: () => setPayModalOpen(true),
              icon: <CreditCard className="w-3.5 h-3.5" />,
            }
          : undefined
      }
    >
      {/* Polaris 2-Column Detail Layout (2/3 Main, 1/3 Side) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Main Column (2/3) */}
        <div className="lg:col-span-2 space-y-4">
          {/* Ordered Items Table Card */}
          <PolarisCard title="Ordered Items" flush={true}>
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-[13px]">
                <thead>
                  <tr className="h-9 bg-[#FAFAFA] border-b border-[#E3E3E3] text-[12px] font-[450] text-[#616161]">
                    <th className="px-4 py-2">Item</th>
                    {!isOfficer && <th className="px-4 py-2">IV-Number</th>}
                    <th className="px-4 py-2 text-center">Quantity</th>
                    {isOfficer && (
                      <>
                        <th className="px-4 py-2 text-right">Unit Price</th>
                        <th className="px-4 py-2 text-right">Line Total</th>
                      </>
                    )}
                    <th className="px-4 py-2 text-right">Slip</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#E3E3E3]">
                  {order.items.map((item, idx) => (
                    <tr key={idx} className="h-11">
                      <td className="px-4 py-2 font-[550] text-[#1A1A1A]">{item.name}</td>
                      {!isOfficer && (
                        <td className="px-4 py-2 text-[#616161]">
                          {(item as any).ivNumber || '—'}
                        </td>
                      )}
                      <td className="px-4 py-2 text-center tabular-nums text-[#303030]">
                        {item.quantity}
                      </td>
                      {isOfficer && (
                        <>
                          <td className="px-4 py-2 text-right tabular-nums text-[#616161]">
                            ৳{(item as any).price}
                          </td>
                          <td className="px-4 py-2 text-right font-[550] text-[#1A1A1A] tabular-nums">
                            ৳{(item as any).lineTotal || (item as any).price * item.quantity}
                          </td>
                        </>
                      )}
                      <td className="px-4 py-2 text-right">
                        <button
                          type="button"
                          onClick={() =>
                            onNavigate('print-slip', {
                              orderNumber: order.orderNumber,
                              category,
                              itemIndex: idx,
                            })
                          }
                          className="h-7 px-2.5 rounded-md border border-[#E3E3E3] bg-white hover:bg-[#F7F7F7] text-[12px] font-[550] text-[#303030] inline-flex items-center space-x-1 cursor-pointer transition-colors shadow-2xs"
                          title="Print cutting slip for this item"
                        >
                          <Scissors className="w-3 h-3 text-[#616161]" />
                          <span>Cutting Slip</span>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="px-4 py-2.5 bg-[#FAFAFA] border-t border-[#E3E3E3] flex justify-end">
              <button
                type="button"
                onClick={() =>
                  onNavigate('print-slip', {
                    orderNumber: order.orderNumber,
                    category,
                  })
                }
                className="h-7 px-3 rounded-lg border border-[#E3E3E3] bg-white hover:bg-[#F3F3F3] text-[12px] font-[550] text-[#303030] inline-flex items-center space-x-1.5 shadow-2xs cursor-pointer"
              >
                <Scissors className="w-3 h-3 text-[#616161]" />
                <span>Print All Slips</span>
              </button>
            </div>
          </PolarisCard>

          {/* Measurements Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Shirt Measurements */}
            <PolarisCard title="Shirt Measurements">
              <div className="grid grid-cols-2 gap-2 text-[12px]">
                {[
                  ['Length', order.shirtMeasurements.length],
                  ['Chest', order.shirtMeasurements.chest],
                  ['Belly', order.shirtMeasurements.belly],
                  ['Hip', order.shirtMeasurements.hip],
                  ['Shoulder', order.shirtMeasurements.shoulder],
                  ['Sleeve', order.shirtMeasurements.sleeve],
                  ['Collar', order.shirtMeasurements.collar],
                  ['Front', order.shirtMeasurements.front],
                  ['Back', order.shirtMeasurements.back],
                ].map(([label, val]) => (
                  <div key={label} className="p-2 bg-[#F7F7F7] rounded-lg">
                    <span className="text-[10px] text-[#616161] block">{label}</span>
                    <span className="font-[650] text-[#1A1A1A]">{val || '—'}</span>
                  </div>
                ))}
              </div>
              {(order.shirtMeasurements.handWrittenNotes || order.shirtMeasurements.extraNotes) && (
                <div className="mt-3 pt-3 border-t border-[#E3E3E3] text-[12px] space-y-1">
                  {order.shirtMeasurements.handWrittenNotes && (
                    <div>
                      <span className="text-[#616161] font-medium">Hand Written Notes: </span>
                      <span className="text-[#1A1A1A]">{order.shirtMeasurements.handWrittenNotes}</span>
                    </div>
                  )}
                  {order.shirtMeasurements.extraNotes && (
                    <div>
                      <span className="text-[#616161] font-medium">Extra Notes: </span>
                      <span className="text-[#1A1A1A]">{order.shirtMeasurements.extraNotes}</span>
                    </div>
                  )}
                </div>
              )}
            </PolarisCard>

            {/* Pant Measurements */}
            <PolarisCard title="Pant Measurements">
              <div className="grid grid-cols-2 gap-2 text-[12px]">
                {[
                  ['Length', order.pantMeasurements.length],
                  ['Waist', order.pantMeasurements.waist],
                  ['Hip', order.pantMeasurements.hip],
                  ['High', order.pantMeasurements.high],
                  ['Thai', order.pantMeasurements.thai],
                  ['Leg Open', order.pantMeasurements.legOpen],
                ].map(([label, val]) => (
                  <div key={label} className="p-2 bg-[#F7F7F7] rounded-lg">
                    <span className="text-[10px] text-[#616161] block">{label}</span>
                    <span className="font-[650] text-[#1A1A1A]">{val || '—'}</span>
                  </div>
                ))}
              </div>
              {(order.pantMeasurements.handWrittenNotes || order.pantMeasurements.extraNotes) && (
                <div className="mt-3 pt-3 border-t border-[#E3E3E3] text-[12px] space-y-1">
                  {order.pantMeasurements.handWrittenNotes && (
                    <div>
                      <span className="text-[#616161] font-medium">Hand Written Notes: </span>
                      <span className="text-[#1A1A1A]">{order.pantMeasurements.handWrittenNotes}</span>
                    </div>
                  )}
                  {order.pantMeasurements.extraNotes && (
                    <div>
                      <span className="text-[#616161] font-medium">Extra Notes: </span>
                      <span className="text-[#1A1A1A]">{order.pantMeasurements.extraNotes}</span>
                    </div>
                  )}
                </div>
              )}
            </PolarisCard>
          </div>
        </div>

        {/* Side Column (1/3) */}
        <div className="space-y-4">
          {/* Customer Information Card */}
          <PolarisCard title="Customer">
            <div className="space-y-2 text-[13px]">
              <div>
                <span className="text-[11px] text-[#616161] block">Name</span>
                <span className="font-[550] text-[#1A1A1A]">{displayName}</span>
              </div>
              <div>
                <span className="text-[11px] text-[#616161] block">BD Number</span>
                <span className="font-[550] text-[#1A1A1A]">{order.customerBdNumber}</span>
              </div>
              <div>
                <span className="text-[11px] text-[#616161] block">Phone</span>
                <span className="text-[#303030]">{order.customerPhone || '—'}</span>
              </div>
            </div>
          </PolarisCard>

          {/* Order Details & Logistics */}
          <PolarisCard title="Order Specifications">
            <div className="space-y-2.5 text-[13px]">
              <div>
                <span className="text-[11px] text-[#616161] block">Order Date</span>
                <span className="text-[#303030]">{order.orderDate}</span>
              </div>
              {isOfficer && (
                <>
                  <div>
                    <span className="text-[11px] text-[#616161] block">Delivery Date</span>
                    <span className="text-[#303030]">{officerOrder?.deliveryDate || '—'}</span>
                  </div>
                  <div>
                    <span className="text-[11px] text-[#616161] block">Branch</span>
                    <span className="font-semibold text-[#005BD3]">
                      {officerOrder?.branch || '—'}
                    </span>
                  </div>
                </>
              )}
              <div>
                <span className="text-[11px] text-[#616161] block">Delivered Date</span>
                <span className="text-[#0C5132] font-medium">{order.deliveredDate || 'Not yet'}</span>
              </div>
              {order.status === 'Delivered' && (order.receiverName || order.receiverPhone) && (
                <div>
                  <span className="text-[11px] text-[#616161] block">Received By</span>
                  <span className="text-[#1A1A1A] font-medium">
                    {order.receiverName || '—'}{order.receiverPhone ? ` (${order.receiverPhone})` : ''}
                  </span>
                </div>
              )}
              <div>
                <span className="text-[11px] text-[#616161] block">Ribbon</span>
                <span className="text-[#303030]">{order.ribbon}</span>
              </div>
              {!isOfficer && (
                <div>
                  <span className="text-[11px] text-[#616161] block">Running Year</span>
                  <span className="text-[#303030] font-[550]">{airmanOrder?.runningYear}</span>
                </div>
              )}
            </div>
          </PolarisCard>

          {/* Financial Summary Card (Officer Only) */}
          {isOfficer && officerOrder && (
            <PolarisCard title="Financial Summary">
              <div className="space-y-2 text-[13px]">
                <div className="flex justify-between">
                  <span className="text-[#616161]">Subtotal</span>
                  <span className="tabular-nums">৳{officerOrder.totalAmount}</span>
                </div>
                {officerOrder.discountAmount > 0 && (
                  <div className="flex justify-between text-[#0C5132]">
                    <span>Discount</span>
                    <span className="tabular-nums">-৳{officerOrder.discountAmount}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span className="text-[#616161]">Advance</span>
                  <span className="tabular-nums">৳{officerOrder.advance || 0}</span>
                </div>
                {officerOrder.payments && officerOrder.payments.length > 0 && (
                  <div className="pt-2 border-t border-[#E3E3E3] space-y-1">
                    <span className="text-[11px] text-[#616161] font-medium block">Payments Received:</span>
                    {officerOrder.payments.map((p, idx) => (
                      <div key={idx} className="flex justify-between text-[12px] text-[#616161]">
                        <span>{p.date}</span>
                        <span className="tabular-nums font-medium text-[#1A1A1A]">৳{p.amount}</span>
                      </div>
                    ))}
                  </div>
                )}
                <div className="pt-2 border-t border-[#E3E3E3] flex justify-between font-[650] text-[14px]">
                  <span>Due Balance</span>
                  <span className={`tabular-nums ${officerOrder.due > 0 ? 'text-[#8E0B21]' : 'text-[#1A1A1A]'}`}>
                    ৳{officerOrder.due}
                  </span>
                </div>
              </div>
            </PolarisCard>
          )}
        </div>
      </div>

      {/* Deliver This Order Prominent Action (when not delivered) */}
      {order.status !== 'Delivered' && (
        <div className="mt-4 p-4 bg-white border border-[#E3E3E3] rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-2xs">
          <div>
            <h4 className="text-[14px] font-[650] text-[#1A1A1A]">Ready for Delivery?</h4>
            <p className="text-[12px] text-[#616161]">
              Review financial summary, receive remaining payment, and confirm delivery.
            </p>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('confirm-delivery', { orderNumber, category, fromDelivery })}
            className="h-9 px-4 rounded-lg bg-[#0C5132] hover:bg-[#083A24] text-white text-[13px] font-[600] inline-flex items-center justify-center space-x-2 shrink-0 shadow-xs cursor-pointer"
          >
            <span>Deliver This Order</span>
          </button>
        </div>
      )}

      {/* Pay Modal */}
      {payModalOpen && isOfficer && officerOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-2xs animate-in fade-in">
          <div
            className="bg-white rounded-2xl max-w-sm w-full overflow-hidden shadow-2xl border border-[#E3E3E3]"
            style={{ borderRadius: 'var(--radius-lg)' }}
          >
            <div className="h-12 px-4 bg-[#F1F1F1] border-b border-[#E3E3E3] flex items-center justify-between">
              <h3 className="text-[14px] font-[650] text-[#1A1A1A]">
                Record Payment for Order #{orderNumber}
              </h3>
              <button
                onClick={() => setPayModalOpen(false)}
                className="p-1 rounded-md text-[#616161] hover:text-[#1A1A1A]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-4 space-y-3 text-[13px]">
              <p className="text-[#616161]">
                Customer <strong>{officerOrder.customerName}</strong> currently has an outstanding
                balance of:
              </p>
              <div className="p-3 bg-[#FFF8F8] border border-[#FEE9E8] rounded-lg text-center">
                <span className="text-[20px] font-[650] text-[#8E0B21]">
                  ৳{officerOrder.due}
                </span>
                <span className="block text-[11px] text-[#8E0B21] mt-0.5 font-medium">
                  Full balance due
                </span>
              </div>
              <p className="text-[12px] text-[#616161]">
                Confirming will mark this full amount as paid and clear the balance to ৳0.
              </p>
            </div>
            <div className="px-4 py-3 bg-[#FAFAFA] border-t border-[#E3E3E3] flex items-center justify-end space-x-2">
              <button
                onClick={() => setPayModalOpen(false)}
                className="h-7 px-3 rounded-lg bg-white border border-[#E3E3E3] hover:bg-[#F3F3F3] text-[#303030] text-[13px] font-[550]"
              >
                Cancel
              </button>
              <button
                onClick={handlePay}
                className="h-7 px-3 rounded-lg bg-[#303030] hover:bg-[#1A1A1A] text-white text-[13px] font-[550]"
              >
                Confirm Payment
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteStep > 0 && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-2xs animate-in fade-in">
          <div
            className="bg-white rounded-2xl max-w-md w-full overflow-hidden shadow-2xl border border-[#E3E3E3]"
            style={{ borderRadius: 'var(--radius-lg)' }}
          >
            <div className="h-12 px-4 bg-[#F1F1F1] border-b border-[#E3E3E3] flex items-center justify-between">
              <h3 className="text-[14px] font-[650] text-[#1A1A1A]">
                Delete {category} Order #{orderNumber}?
              </h3>
              <button
                onClick={() => setDeleteStep(0)}
                className="p-1 rounded-md text-[#616161] hover:text-[#1A1A1A]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-4 space-y-3 text-[13px]">
              {deleteStep === 1 ? (
                <>
                  <p className="text-[#616161]">
                    Are you sure you want to delete {category} Order{' '}
                    <strong>#{orderNumber}</strong> ({displayName})?
                  </p>
                  <div className="p-3 bg-[#FAFAFA] rounded-lg border border-[#E3E3E3] text-[12px] text-[#616161]">
                    The order will be archived into <strong>Deleted History</strong> in Settings and can
                    be restored. Subsequent order numbers will shift down by 1.
                  </div>
                </>
              ) : (
                <div className="p-3 bg-[#FEE9E8] rounded-lg border border-[#FCDAD7] text-[#8E0B21] text-[12px] space-y-1">
                  <div className="font-[650] flex items-center space-x-1">
                    <AlertTriangle className="w-4 h-4" />
                    <span>Please Confirm Final Deletion</span>
                  </div>
                  <p>Order #{orderNumber} will be removed from active orders.</p>
                </div>
              )}
            </div>
            <div className="px-4 py-3 bg-[#FAFAFA] border-t border-[#E3E3E3] flex items-center justify-end space-x-2">
              <button
                onClick={() => setDeleteStep(0)}
                className="h-7 px-3 rounded-lg bg-white border border-[#E3E3E3] hover:bg-[#F3F3F3] text-[#303030] text-[13px] font-[550]"
              >
                Cancel
              </button>
              {deleteStep === 1 ? (
                <button
                  onClick={handleDeleteStep1}
                  className="h-7 px-3 rounded-lg bg-[#303030] hover:bg-[#1A1A1A] text-white text-[13px] font-[550]"
                >
                  Continue
                </button>
              ) : (
                <button
                  onClick={handleDeleteStep2}
                  className="h-7 px-3 rounded-lg bg-[#8E0B21] hover:bg-[#72091A] text-white text-[13px] font-[550]"
                >
                  Confirm Delete
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </PolarisPage>
  );
};
