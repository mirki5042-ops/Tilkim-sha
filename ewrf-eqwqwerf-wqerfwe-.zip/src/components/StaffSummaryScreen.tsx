import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { StaffWorker } from '../types/index.ts';
import {
  formatDate,
  formatMonth,
  calculateWorkerMonthHishab,
} from '../utils/logic.ts';
import { MONTH_METADATA } from '../utils/starterData.ts';
import { exportStaffSummaryPDF } from '../utils/pdfGenerator.ts';
import { PolarisPage } from './polaris/PolarisPage.tsx';
import { PolarisCard } from './polaris/PolarisCard.tsx';
import { PolarisBadge } from './polaris/PolarisBadge.tsx';
import {
  Search,
  RotateCw,
  Download,
  CreditCard,
  Printer,
  X,
  ChevronLeft,
  ChevronRight,
  Trophy,
  BarChart3,
  Snowflake,
  Heart,
  Sprout,
  CloudRain,
  Flower2,
  Sun,
  CloudLightning,
  Umbrella,
  Wheat,
  Moon,
  Wind,
  Gift,
  FileText,
} from 'lucide-react';
import { ScreenName } from './Navbar.tsx';

interface StaffSummaryScreenProps {
  onNavigate: (screen: ScreenName, params?: any) => void;
}

const MonthIconSmall: React.FC<{ symbol: string; className?: string }> = ({ symbol, className }) => {
  switch (symbol) {
    case 'Snowflake':
      return <Snowflake className={className} />;
    case 'Heart':
      return <Heart className={className} />;
    case 'Sprout':
      return <Sprout className={className} />;
    case 'CloudRain':
      return <CloudRain className={className} />;
    case 'Flower2':
      return <Flower2 className={className} />;
    case 'Sun':
      return <Sun className={className} />;
    case 'CloudLightning':
      return <CloudLightning className={className} />;
    case 'Umbrella':
      return <Umbrella className={className} />;
    case 'Wheat':
      return <Wheat className={className} />;
    case 'Moon':
      return <Moon className={className} />;
    case 'Wind':
      return <Wind className={className} />;
    case 'Gift':
      return <Gift className={className} />;
    default:
      return <FileText className={className} />;
  }
};

export const StaffSummaryScreen: React.FC<StaffSummaryScreenProps> = ({ onNavigate }) => {
  const { state, addWorkerPayment } = useApp();

  const currentYear = new Date().getFullYear();
  const [selectedYear, setSelectedYear] = useState<number>(currentYear);
  const [selectedMonthIndex, setSelectedMonthIndex] = useState<number | 'all'>('all');

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'All' | 'Unpaid' | 'Partial' | 'Paid'>('All');
  const [toastMessage, setToastMessage] = useState('');

  // Pay Modal State
  const [payWorker, setPayWorker] = useState<StaffWorker | null>(null);
  const [payMonth, setPayMonth] = useState(formatMonth());
  const [payAmount, setPayAmount] = useState<number>(0);
  const [payDate, setPayDate] = useState(formatDate());
  const [payNote, setPayNote] = useState('');
  const [payError, setPayError] = useState('');

  // Resolved Month String if specific month selected
  const activeMonthStr = useMemo(() => {
    if (selectedMonthIndex === 'all') return undefined;
    const num = String(selectedMonthIndex + 1).padStart(2, '0');
    return `${selectedYear}-${num}`;
  }, [selectedYear, selectedMonthIndex]);

  // Per worker calculation
  const workerSummaryList = useMemo(() => {
    return state.workers
      .map((worker) => {
        const hishab = calculateWorkerMonthHishab(
          worker.id,
          state.workerRows,
          state.workerPayments,
          activeMonthStr
        );

        // 12-month earnings for the month strip
        const monthlyEarnings = MONTH_METADATA.map((meta) => {
          const mStr = `${selectedYear}-${meta.numStr}`;
          const mHishab = calculateWorkerMonthHishab(worker.id, state.workerRows, state.workerPayments, mStr);
          return mHishab.totalAmount;
        });

        return {
          worker,
          ...hishab,
          monthlyEarnings,
        };
      })
      .filter((item) => {
        // Status filter
        if (statusFilter !== 'All' && item.status !== statusFilter) return false;

        // Search query
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase().trim();
          const matchesName = item.worker.name.toLowerCase().includes(q);
          const matchesBangla = (item.worker.banglaName || '').toLowerCase().includes(q);
          if (!matchesName && !matchesBangla) return false;
        }

        return true;
      });
  }, [state.workers, state.workerRows, state.workerPayments, activeMonthStr, selectedYear, statusFilter, searchQuery]);

  // Aggregate Card Totals
  const cardTotals = useMemo(() => {
    let sumAmount = 0;
    let sumKhoroch = 0;
    let sumPayable = 0;
    let sumReceived = 0;
    let sumDue = 0;

    workerSummaryList.forEach((w) => {
      sumAmount += w.totalAmount;
      sumKhoroch += w.totalKhoroch;
      sumPayable += w.netPayable;
      sumReceived += w.received;
      sumDue += Math.max(0, w.due);
    });

    return {
      activeStaffCount: state.workers.filter((w) => w.active).length,
      sumAmount,
      sumKhoroch,
      sumPayable,
      sumReceived,
      sumDue,
    };
  }, [workerSummaryList, state.workers]);

  // Top Earners (Top 5 workers)
  const topEarners = useMemo(() => {
    return [...workerSummaryList]
      .filter((w) => w.totalAmount > 0)
      .sort((a, b) => b.totalAmount - a.totalAmount)
      .slice(0, 5);
  }, [workerSummaryList]);

  // Due By Month Bar Chart Data
  const dueByMonth = useMemo(() => {
    return MONTH_METADATA.map((meta) => {
      const mStr = `${selectedYear}-${meta.numStr}`;
      let monthDue = 0;

      state.workers.forEach((w) => {
        const h = calculateWorkerMonthHishab(w.id, state.workerRows, state.workerPayments, mStr);
        if (h.due > 0) {
          monthDue += h.due;
        }
      });

      return {
        meta,
        due: monthDue,
      };
    });
  }, [state.workers, state.workerRows, state.workerPayments, selectedYear]);

  const maxMonthDue = useMemo(() => {
    const maxVal = Math.max(...dueByMonth.map((d) => d.due));
    return maxVal > 0 ? maxVal : 1;
  }, [dueByMonth]);

  const handleRecalculate = () => {
    setToastMessage('Totals recalculated across all records');
    setTimeout(() => setToastMessage(''), 2500);
  };

  const handleDownloadPDF = () => {
    if (workerSummaryList.length === 0) {
      setToastMessage('Nothing to download for this selection.');
      setTimeout(() => setToastMessage(''), 3000);
      return;
    }
    setToastMessage('Preparing PDF…');
    setTimeout(() => {
      try {
        exportStaffSummaryPDF(
          state.settings.invoiceShopName || 'Raymond',
          activeMonthStr || `${selectedYear}`,
          workerSummaryList.map((item) => ({
            name: item.worker.banglaName
              ? `${item.worker.name} (${item.worker.banglaName})`
              : item.worker.name,
            role: 'Tailor',
            phone: '—',
            totalWorks: item.worksCount || 0,
            totalAmount: item.totalAmount || 0,
            totalKhoroch: item.totalKhoroch || 0,
            netPayable: item.netPayable || 0,
            received: item.received || 0,
            due: item.due || 0,
            status: item.status || '—',
          }))
        );
        setToastMessage('PDF downloaded');
        setTimeout(() => setToastMessage(''), 3000);
      } catch (err) {
        console.error(err);
        setToastMessage('Failed to generate PDF');
        setTimeout(() => setToastMessage(''), 3000);
      }
    }, 150);
  };

  const handleOpenPay = (worker: StaffWorker) => {
    setPayWorker(worker);
    setPayError('');
    setPayDate(formatDate());
    setPayNote('');

    const targetM = activeMonthStr || formatMonth();
    setPayMonth(targetM);

    const h = calculateWorkerMonthHishab(worker.id, state.workerRows, state.workerPayments, targetM);
    setPayAmount(Math.max(0, h.due));
  };

  const handleConfirmPay = () => {
    if (!payWorker) return;
    setPayError('');

    if (payAmount <= 0) {
      setPayError('Payment amount must be greater than 0.');
      return;
    }

    const h = calculateWorkerMonthHishab(payWorker.id, state.workerRows, state.workerPayments, payMonth);
    if (payAmount > h.due) {
      setPayError(`Amount is more than the Due of ৳${h.due}.`);
      return;
    }

    addWorkerPayment({
      workerId: payWorker.id,
      forMonth: payMonth,
      amount: payAmount,
      date: payDate,
      note: payNote.trim(),
    });

    setPayWorker(null);
    setToastMessage(`Payment of ৳${payAmount} recorded for ${payWorker.name}`);
    setTimeout(() => setToastMessage(''), 3000);
  };

  return (
    <PolarisPage
      title="Staff Summary"
      subtitle="Tailoring staff work totals, advances, due balances, and payslips"
      secondaryActions={[
        {
          label: 'Recalculate',
          onClick: handleRecalculate,
          icon: <RotateCw className="w-3.5 h-3.5" />,
        },
        {
          label: 'Download PDF',
          onClick: handleDownloadPDF,
          icon: <Download className="w-3.5 h-3.5" />,
        },
      ]}
      fullWidth={true}
    >
      {/* Toast Notification */}
      {toastMessage && (
        <div className="p-3 bg-[#1A1A1A] text-white text-[13px] font-[550] rounded-xl flex items-center justify-between shadow-lg">
          <span>{toastMessage}</span>
          <button onClick={() => setToastMessage('')} className="text-gray-400 hover:text-white ml-2">
            ✕
          </button>
        </div>
      )}

      {/* Polaris 6-Card Metric Row */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="bg-white p-3.5 rounded-xl border border-[#E3E3E3] shadow-[0_1px_0_rgba(26,26,26,0.07)]">
          <span className="text-[11px] text-[#616161] font-[550] block">Total Staff</span>
          <span className="text-[20px] font-[650] text-[#1A1A1A] mt-0.5 block tabular-nums">
            {cardTotals.activeStaffCount}
          </span>
        </div>
        <div className="bg-white p-3.5 rounded-xl border border-[#E3E3E3] shadow-[0_1px_0_rgba(26,26,26,0.07)]">
          <span className="text-[11px] text-[#616161] font-[550] block">Total Amount</span>
          <span className="text-[20px] font-[650] text-[#1A1A1A] mt-0.5 block tabular-nums">
            ৳{cardTotals.sumAmount.toLocaleString()}
          </span>
        </div>
        <div className="bg-white p-3.5 rounded-xl border border-[#E3E3E3] shadow-[0_1px_0_rgba(26,26,26,0.07)]">
          <span className="text-[11px] text-[#616161] font-[550] block">Total Khorach</span>
          <span className="text-[20px] font-[650] text-[#D97706] mt-0.5 block tabular-nums">
            ৳{cardTotals.sumKhoroch.toLocaleString()}
          </span>
        </div>
        <div className="bg-white p-3.5 rounded-xl border border-[#E3E3E3] shadow-[0_1px_0_rgba(26,26,26,0.07)]">
          <span className="text-[11px] text-[#616161] font-[550] block">Total Payable</span>
          <span className="text-[20px] font-[650] text-[#005BD3] mt-0.5 block tabular-nums">
            ৳{cardTotals.sumPayable.toLocaleString()}
          </span>
        </div>
        <div className="bg-white p-3.5 rounded-xl border border-[#E3E3E3] shadow-[0_1px_0_rgba(26,26,26,0.07)]">
          <span className="text-[11px] text-[#616161] font-[550] block">Total Received</span>
          <span className="text-[20px] font-[650] text-[#0C5132] mt-0.5 block tabular-nums">
            ৳{cardTotals.sumReceived.toLocaleString()}
          </span>
        </div>
        <div className="bg-white p-3.5 rounded-xl border border-[#E3E3E3] shadow-[0_1px_0_rgba(26,26,26,0.07)]">
          <span className="text-[11px] text-[#616161] font-[550] block">Total Due</span>
          <span
            className={`text-[20px] font-[650] mt-0.5 block tabular-nums ${
              cardTotals.sumDue > 0 ? 'text-[#8E0B21]' : 'text-[#1A1A1A]'
            }`}
          >
            ৳{cardTotals.sumDue.toLocaleString()}
          </span>
        </div>
      </div>

      {/* Top Earners Row */}
      {topEarners.length > 0 && (
        <PolarisCard title={`Top Earners (${activeMonthStr || selectedYear})`}>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
            {topEarners.map((item, idx) => (
              <div
                key={item.worker.id}
                onClick={() =>
                  onNavigate('worker-page', {
                    workerId: item.worker.id,
                    month: activeMonthStr || formatMonth(),
                  })
                }
                className="p-3 bg-[#F7F7F7] hover:bg-[#EBEBEB] rounded-xl border border-[#E3E3E3] cursor-pointer transition-all flex flex-col justify-between"
              >
                <div className="flex items-center justify-between">
                  <span className="w-5 h-5 rounded-full bg-[#1A1A1A] text-white text-[10px] font-bold flex items-center justify-center">
                    #{idx + 1}
                  </span>
                  <Trophy className="w-3.5 h-3.5 text-[#D97706]" />
                </div>
                <div className="mt-2">
                  <div className="font-[650] text-[13px] text-[#1A1A1A] truncate">
                    {item.worker.name}
                  </div>
                  <div className="text-[14px] font-[650] text-[#005BD3] mt-0.5 tabular-nums">
                    ৳{item.totalAmount.toLocaleString()}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </PolarisCard>
      )}

      {/* Due By Month Bar Chart Card */}
      <PolarisCard
        title={`Due By Month (${selectedYear})`}
        actions={
          <div className="flex items-center space-x-1.5">
            <button
              onClick={() => setSelectedYear((y) => y - 1)}
              className="p-1 rounded text-[#616161] hover:bg-[#F1F1F1]"
              aria-label="Previous year"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="text-[12px] font-[650] text-[#1A1A1A]">{selectedYear}</span>
            <button
              onClick={() => setSelectedYear((y) => y + 1)}
              className="p-1 rounded text-[#616161] hover:bg-[#F1F1F1]"
              aria-label="Next year"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        }
      >
        <div className="grid grid-cols-6 sm:grid-cols-12 gap-2 pt-2 items-end h-28">
          {dueByMonth.map((d, index) => {
            const heightPercent = Math.min(100, Math.round((d.due / maxMonthDue) * 100));

            return (
              <div
                key={d.meta.monthIndex}
                onClick={() => setSelectedMonthIndex(index)}
                className="flex flex-col items-center h-full justify-end cursor-pointer group"
                title={`${d.meta.name}: Due ৳${d.due}`}
              >
                <div
                  style={{
                    backgroundColor: d.due > 0 ? d.meta.strong : '#E3E3E3',
                    height: d.due > 0 ? `${Math.max(12, heightPercent)}%` : '4px',
                  }}
                  className="w-full max-w-[24px] rounded-t-md transition-all group-hover:opacity-80"
                />
                <span className="text-[11px] font-[550] text-[#616161] mt-1.5 truncate">
                  {d.meta.name.slice(0, 3)}
                </span>
              </div>
            );
          })}
        </div>
      </PolarisCard>

      {/* Filters Toolbar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2">
          {/* Month Filter */}
          <div className="flex items-center space-x-1.5">
            <span className="text-[12px] font-[550] text-[#616161]">Month:</span>
            <select
              value={selectedMonthIndex === 'all' ? 'all' : selectedMonthIndex}
              onChange={(e) =>
                setSelectedMonthIndex(e.target.value === 'all' ? 'all' : parseInt(e.target.value, 10))
              }
              className="h-7 px-2.5 text-[12px] bg-white border border-[#E3E3E3] rounded-lg text-[#303030] font-[550] focus:outline-none focus:border-[#303030] cursor-pointer shadow-2xs"
            >
              <option value="all">All Months ({selectedYear})</option>
              {MONTH_METADATA.map((m) => (
                <option key={m.monthIndex} value={m.monthIndex}>
                  {m.name} ({m.banglaName})
                </option>
              ))}
            </select>
          </div>

          {/* Status Filter */}
          <div className="flex items-center space-x-1.5">
            <span className="text-[12px] font-[550] text-[#616161]">Status:</span>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as any)}
              className="h-7 px-2.5 text-[12px] bg-white border border-[#E3E3E3] rounded-lg text-[#303030] font-[550] focus:outline-none focus:border-[#303030] cursor-pointer shadow-2xs"
            >
              <option value="All">All Status</option>
              <option value="Unpaid">Unpaid</option>
              <option value="Partial">Partial</option>
              <option value="Paid">Paid</option>
            </select>
          </div>
        </div>

        {/* Search */}
        <div className="relative w-full sm:w-60">
          <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-[#8A8A8A]" />
          <input
            type="text"
            placeholder="Search worker name..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full h-7 pl-8 pr-3 text-[12px] bg-white border border-[#E3E3E3] rounded-lg focus:outline-none focus:border-[#303030] text-[#303030]"
          />
        </div>
      </div>

      {/* Main Table Card (54px Polaris IndexTable) */}
      <PolarisCard flush={true}>
        <div className="overflow-x-auto">
          <table className="w-full border-collapse text-left">
            <thead>
              <tr className="h-9 border-b border-[#E3E3E3] bg-white text-[13px] font-[450] text-[#616161]">
                <th className="px-3 w-10 text-center">#</th>
                <th className="px-3 text-left">Staff Name</th>
                <th className="px-2 text-center w-64">12-Month Strip</th>
                <th className="px-3 text-right">Total Amount</th>
                <th className="px-3 text-right">Khorach</th>
                <th className="px-3 text-right">Net Payable</th>
                <th className="px-3 text-right">Received</th>
                <th className="px-3 text-right">Due</th>
                <th className="px-3 text-center w-28">Status</th>
                <th className="px-3 text-right w-36">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#E3E3E3] text-[13px]">
              {workerSummaryList.map((item, idx) => (
                <tr
                  key={item.worker.id}
                  className="h-[54px] hover:bg-[#F7F7F7] transition-colors"
                >
                  <td className="px-3 text-center text-[#616161] font-medium">{idx + 1}</td>

                  {/* Staff Name with Bangla */}
                  <td className="px-3">
                    <div
                      onClick={() =>
                        onNavigate('worker-page', {
                          workerId: item.worker.id,
                          month: activeMonthStr || formatMonth(),
                        })
                      }
                      className="font-[650] text-[#1A1A1A] hover:text-[#005BD3] cursor-pointer"
                    >
                      {item.worker.name}
                    </div>
                    {item.worker.banglaName && (
                      <div className="text-[11px] text-[#616161]">{item.worker.banglaName}</div>
                    )}
                  </td>

                  {/* 12-Month Strip */}
                  <td className="px-2 text-center">
                    <div className="flex items-center justify-center space-x-1">
                      {MONTH_METADATA.map((meta, mIdx) => {
                        const earned = item.monthlyEarnings[mIdx] || 0;
                        const hasWork = earned > 0;
                        const monthStr = `${selectedYear}-${meta.numStr}`;

                        return (
                          <div
                            key={meta.monthIndex}
                            onClick={() =>
                              onNavigate('worker-page', {
                                workerId: item.worker.id,
                                month: monthStr,
                              })
                            }
                            style={{
                              backgroundColor: hasWork ? meta.strong : '#EBEBEB',
                              color: hasWork ? '#FFFFFF' : '#8A8A8A',
                            }}
                            title={`${meta.name}: ৳${earned.toLocaleString()} earned`}
                            className={`w-5 h-5 rounded flex items-center justify-center cursor-pointer transition-transform hover:scale-110 shadow-2xs`}
                          >
                            <MonthIconSmall symbol={meta.symbol} className="w-2.5 h-2.5" />
                          </div>
                        );
                      })}
                    </div>
                  </td>

                  <td className="px-3 text-right font-[550] text-[#1A1A1A] tabular-nums">
                    ৳{item.totalAmount.toLocaleString()}
                  </td>
                  <td className="px-3 text-right text-[#D97706] tabular-nums">
                    ৳{item.totalKhoroch.toLocaleString()}
                  </td>
                  <td className="px-3 text-right font-[650] text-[#1A1A1A] tabular-nums">
                    ৳{item.netPayable.toLocaleString()}
                  </td>
                  <td className="px-3 text-right text-[#0C5132] tabular-nums">
                    ৳{item.received.toLocaleString()}
                  </td>
                  <td
                    className={`px-3 text-right font-[650] tabular-nums ${
                      item.due > 0 ? 'text-[#8E0B21]' : 'text-[#616161]'
                    }`}
                  >
                    ৳{item.due.toLocaleString()}
                  </td>

                  {/* Status Badge */}
                  <td className="px-3 text-center">
                    <PolarisBadge
                      tone={
                        item.status === 'Paid'
                          ? 'success'
                          : item.status === 'Partial'
                          ? 'warning'
                          : item.status === 'Unpaid'
                          ? 'critical'
                          : 'neutral'
                      }
                    >
                      {item.status}
                    </PolarisBadge>
                  </td>

                  {/* Actions */}
                  <td className="px-3 text-right">
                    <div className="flex items-center justify-end space-x-1">
                      {item.due > 0 && (
                        <button
                          onClick={() => handleOpenPay(item.worker)}
                          title="Record Payment"
                          className="h-6 px-2 rounded bg-[#008060] hover:bg-[#006e52] text-white text-[11px] font-[550] inline-flex items-center space-x-1 transition-colors"
                        >
                          <CreditCard className="w-3 h-3" />
                          <span>Pay</span>
                        </button>
                      )}
                      <button
                        onClick={() =>
                          onNavigate('print-worker-statement', {
                            workerId: item.worker.id,
                            month: activeMonthStr || formatMonth(),
                          })
                        }
                        title="Print Payslip"
                        className="p-1 text-[#616161] hover:text-[#1A1A1A] hover:bg-[#EBEBEB] rounded"
                        aria-label="Print payslip"
                      >
                        <Printer className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </PolarisCard>

      {/* Payment Modal */}
      {payWorker && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-2xs animate-in fade-in">
          <div
            className="bg-white rounded-2xl max-w-sm w-full overflow-hidden shadow-2xl border border-[#E3E3E3]"
            style={{ borderRadius: 'var(--radius-lg)' }}
          >
            <div className="h-12 px-4 bg-[#F1F1F1] border-b border-[#E3E3E3] flex items-center justify-between">
              <h3 className="text-[14px] font-[650] text-[#1A1A1A]">
                Pay Worker: {payWorker.name}
              </h3>
              <button
                onClick={() => setPayWorker(null)}
                className="p-1 rounded text-[#616161] hover:text-[#1A1A1A]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-4 space-y-3 text-[13px]">
              {payError && (
                <div className="p-2 bg-[#FEE9E8] text-[#8E0B21] text-[12px] font-medium rounded-lg">
                  {payError}
                </div>
              )}
              <div>
                <label className="block text-[11px] text-[#616161] font-medium mb-1">
                  For Month
                </label>
                <input
                  type="month"
                  value={payMonth}
                  onChange={(e) => setPayMonth(e.target.value)}
                  className="w-full h-8 px-2.5 text-[12px] bg-white border border-[#E3E3E3] rounded-lg"
                />
              </div>
              <div>
                <label className="block text-[11px] text-[#616161] font-medium mb-1">
                  Payment Amount (৳)
                </label>
                <input
                  type="number"
                  min="1"
                  value={payAmount}
                  onChange={(e) => setPayAmount(parseFloat(e.target.value) || 0)}
                  className="w-full h-8 px-2.5 text-[13px] bg-white border border-[#E3E3E3] rounded-lg font-[650]"
                />
              </div>
              <div>
                <label className="block text-[11px] text-[#616161] font-medium mb-1">Payment Date</label>
                <input
                  type="date"
                  value={payDate}
                  onChange={(e) => setPayDate(e.target.value)}
                  className="w-full h-8 px-2.5 text-[12px] bg-white border border-[#E3E3E3] rounded-lg"
                />
              </div>
              <div>
                <label className="block text-[11px] text-[#616161] font-medium mb-1">Notes</label>
                <input
                  type="text"
                  placeholder="e.g. Bank transfer, cash payment"
                  value={payNote}
                  onChange={(e) => setPayNote(e.target.value)}
                  className="w-full h-8 px-2.5 text-[12px] bg-white border border-[#E3E3E3] rounded-lg"
                />
              </div>
            </div>
            <div className="px-4 py-3 bg-[#FAFAFA] border-t border-[#E3E3E3] flex items-center justify-end space-x-2">
              <button
                onClick={() => setPayWorker(null)}
                className="h-7 px-3 rounded-lg bg-white border border-[#E3E3E3] text-[#303030] text-[13px] font-[550]"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmPay}
                className="h-7 px-3 rounded-lg bg-[#303030] hover:bg-[#1A1A1A] text-white text-[13px] font-[550]"
              >
                Record Payment
              </button>
            </div>
          </div>
        </div>
      )}
    </PolarisPage>
  );
};
