import React, { useState, useEffect, useMemo } from 'react';
import { useApp } from '../context/AppContext.tsx';
import {
  AirmanItemDefinition,
  AirmanOrder,
  AirmanOrderItem,
  PantMeasurements,
  ShirtMeasurements,
  Customer,
} from '../types/index.ts';
import {
  INITIAL_PANT_MEASUREMENTS,
  INITIAL_SHIRT_MEASUREMENTS,
} from '../utils/starterData.ts';
import {
  formatDate,
  getBdDigits,
  getLatestMeasurementsForCustomer,
  normalizeBdNumber,
  validateRunningYear,
} from '../utils/logic.ts';
import { ConfirmModal } from './ConfirmModal.tsx';
import {
  Plus,
  Trash2,
  Scissors,
  ArrowLeft,
  AlertTriangle,
  Search,
  Settings as SettingsIcon,
  ChevronDown,
  Sparkles,
  Calendar,
  Ruler,
  Hash,
} from 'lucide-react';
import { ScreenName } from './Navbar.tsx';
import { PolarisPage } from './polaris/PolarisPage.tsx';
import { PolarisCard } from './polaris/PolarisCard.tsx';
import { PolarisBadge } from './polaris/PolarisBadge.tsx';
import { CompactAirmanItemsPicker } from './CompactAirmanItemsPicker.tsx';

interface AirmanOrderFormProps {
  orderNumber?: number;
  draftId?: string;
  onNavigate: (screen: ScreenName, params?: any) => void;
}

const LOCAL_AIR_DRAFT_KEY = 'airman_order_local_autosave';

export const AirmanOrderForm: React.FC<AirmanOrderFormProps> = ({
  orderNumber,
  draftId,
  onNavigate,
}) => {
  const { state, saveAirmanOrder, saveDraft, deleteDraft, addRunningYear } = useApp();

  const isEdit = typeof orderNumber === 'number';
  const existingOrder = isEdit ? state.airmanOrders.find((o) => o.orderNumber === orderNumber) : null;
  const existingDraft = draftId ? state.drafts.find((d) => d.id === draftId) : null;
  const isDraftMode = !!draftId || (!isEdit && !!existingDraft);

  // Form State
  const [items, setItems] = useState<AirmanOrderItem[]>(() => {
    if (existingOrder?.items && existingOrder.items.length > 0) return existingOrder.items;
    if (existingDraft?.airmanItems && existingDraft.airmanItems.length > 0) return existingDraft.airmanItems;
    return [];
  });

  const [editingRow, setEditingRow] = useState<{
    catalogItem: AirmanItemDefinition | null;
    quantity: number;
    ivNumber: string;
  }>(() => {
    const first = state.settings.airmanItems[0];
    return {
      catalogItem: first || null,
      quantity: 1,
      ivNumber: '',
    };
  });
  const [isEditingRowTouched, setIsEditingRowTouched] = useState(false);
  const [shirt, setShirt] = useState<ShirtMeasurements>(INITIAL_SHIRT_MEASUREMENTS);
  const [pant, setPant] = useState<PantMeasurements>(INITIAL_PANT_MEASUREMENTS);

  const [bdDigits, setBdDigits] = useState('');
  const [customerName, setCustomerName] = useState('');
  const [phone, setPhone] = useState('');
  const [ribbon, setRibbon] = useState(state.settings.ribbonValues[0] || '1');
  const [runningYear, setRunningYear] = useState(state.settings.runningYears[0] || '2026–2027');
  const [orderDate, setOrderDate] = useState(formatDate());
  const [deliveryDate, setDeliveryDate] = useState('');

  // Inline Add Year State
  const [isAddingYear, setIsAddingYear] = useState(false);
  const [newYearInput, setNewYearInput] = useState('');
  const [addYearError, setAddYearError] = useState('');

  // Suggestions & UI
  const [showBdSuggestions, setShowBdSuggestions] = useState(false);
  const [showNameSuggestions, setShowNameSuggestions] = useState(false);
  const [isDirty, setIsDirty] = useState(false);
  const [formError, setFormError] = useState('');
  const [savedNameNotice, setSavedNameNotice] = useState('');
  const [measurementsLoadedNote, setMeasurementsLoadedNote] = useState('');
  const [offerMeasurementPrompt, setOfferMeasurementPrompt] = useState<{
    orderNumber: number;
    shirt: any;
    pant: any;
  } | null>(null);

  const [cancelModalOpen, setCancelModalOpen] = useState(false);
  const [deleteDraftModalOpen, setDeleteDraftModalOpen] = useState(false);
  const [resumePromptOpen, setResumePromptOpen] = useState(false);
  const [autosaveStatus, setAutosaveStatus] = useState('');

  // Open item dropdown index
  const [openItemDropdownIndex, setOpenItemDropdownIndex] = useState<number | null>(null);

  // Unsaved changes beforeunload handler
  useEffect(() => {
    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
      if (isDirty) {
        e.preventDefault();
        e.returnValue = '';
      }
    };
    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => window.removeEventListener('beforeunload', handleBeforeUnload);
  }, [isDirty]);

  useEffect(() => {
    if (existingOrder) {
      if (existingOrder.items && existingOrder.items.length > 0) {
        setItems(existingOrder.items);
      }
      setShirt(existingOrder.shirtMeasurements || INITIAL_SHIRT_MEASUREMENTS);
      setPant(existingOrder.pantMeasurements || INITIAL_PANT_MEASUREMENTS);
      setBdDigits(getBdDigits(existingOrder.customerBdNumber || ''));
      setCustomerName(existingOrder.customerName || '');
      setPhone(existingOrder.customerPhone || '');
      setRibbon(existingOrder.ribbon || state.settings.ribbonValues[0] || '1');
      setRunningYear(existingOrder.runningYear || state.settings.runningYears[0] || '2026–2027');
      setOrderDate(existingOrder.orderDate || formatDate());
      setDeliveryDate(existingOrder.deliveredDate || '');
    } else if (existingDraft) {
      if (existingDraft.airmanItems && existingDraft.airmanItems.length > 0) {
        setItems(existingDraft.airmanItems);
      }
      setShirt(existingDraft.shirtMeasurements || INITIAL_SHIRT_MEASUREMENTS);
      setPant(existingDraft.pantMeasurements || INITIAL_PANT_MEASUREMENTS);
      setBdDigits(getBdDigits(existingDraft.customerBdNumber || ''));
      setCustomerName(existingDraft.customerName || '');
      setPhone(existingDraft.customerPhone || '');
      setRibbon(existingDraft.ribbon || state.settings.ribbonValues[0] || '1');
      setRunningYear(existingDraft.runningYear || state.settings.runningYears[0] || '2026–2027');
      setOrderDate(existingDraft.orderDate || formatDate());
      setDeliveryDate(existingDraft.deliveryDate || '');
    } else {
      try {
        const saved = localStorage.getItem(LOCAL_AIR_DRAFT_KEY);
        if (saved) {
          const parsed = JSON.parse(saved);
          if (parsed && (parsed.bdDigits || parsed.items?.length > 0)) {
            setResumePromptOpen(true);
          }
        }
      } catch {}
    }
  }, [existingOrder, existingDraft]);

  const loadLocalDraft = () => {
    try {
      const saved = localStorage.getItem(LOCAL_AIR_DRAFT_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.items && parsed.items.length > 0) setItems(parsed.items);
        if (parsed.shirt) setShirt(parsed.shirt);
        if (parsed.pant) setPant(parsed.pant);
        if (parsed.bdDigits) setBdDigits(parsed.bdDigits);
        if (parsed.customerName) setCustomerName(parsed.customerName);
        if (parsed.phone) setPhone(parsed.phone);
        if (parsed.ribbon) setRibbon(parsed.ribbon);
        if (parsed.runningYear) setRunningYear(parsed.runningYear);
        if (parsed.orderDate) setOrderDate(parsed.orderDate);
        if (parsed.deliveryDate) setDeliveryDate(parsed.deliveryDate);
      }
    } catch {}
    setResumePromptOpen(false);
  };

  const clearLocalDraft = () => {
    localStorage.removeItem(LOCAL_AIR_DRAFT_KEY);
    setResumePromptOpen(false);
  };

  // Local Autosave
  useEffect(() => {
    if (isEdit) return;

    const timer = setTimeout(() => {
      const payload = {
        items,
        shirt,
        pant,
        bdDigits,
        customerName,
        phone,
        ribbon,
        runningYear,
        orderDate,
        deliveryDate,
        timestamp: Date.now(),
      };
      if (bdDigits || items.length > 0 || customerName) {
        localStorage.setItem(LOCAL_AIR_DRAFT_KEY, JSON.stringify(payload));
        setAutosaveStatus('Draft saved locally');
      }
    }, 1500);

    return () => clearTimeout(timer);
  }, [
    isEdit,
    items,
    shirt,
    pant,
    bdDigits,
    customerName,
    phone,
    ribbon,
    runningYear,
    orderDate,
    deliveryDate,
  ]);

  // Suggestions
  const bdSuggestions = useMemo(() => {
    if (!bdDigits || bdDigits.length < 1) return [];
    const query = bdDigits.trim();
    const matches = state.customers.filter(
      (c) => c.category === 'Airman' && getBdDigits(c.bdNumber).includes(query)
    );

    return matches.slice(0, 5).map((customer) => {
      const lastOrder = state.airmanOrders
        .filter((o) => o.customerBdNumber === customer.bdNumber)
        .sort((a, b) => b.orderNumber - a.orderNumber)[0];

      return {
        customer,
        lastOrderDate: lastOrder?.orderDate || '',
        lastOrderNumber: lastOrder?.orderNumber || null,
      };
    });
  }, [bdDigits, state.customers, state.airmanOrders]);

  const nameSuggestions = useMemo(() => {
    if (!customerName || customerName.trim().length < 2) return [];
    const query = customerName.toLowerCase().trim();
    const matches = state.customers.filter(
      (c) => c.category === 'Airman' && c.name.toLowerCase().includes(query)
    );

    return matches.slice(0, 5).map((customer) => {
      const lastOrder = state.airmanOrders
        .filter((o) => o.customerBdNumber === customer.bdNumber)
        .sort((a, b) => b.orderNumber - a.orderNumber)[0];

      return {
        customer,
        lastOrderDate: lastOrder?.orderDate || '',
        lastOrderNumber: lastOrder?.orderNumber || null,
      };
    });
  }, [customerName, state.customers, state.airmanOrders]);

  const handleSelectCustomer = (customer: Customer) => {
    setCustomerName(customer.name);
    setBdDigits(getBdDigits(customer.bdNumber));
    if (customer.phone) setPhone(customer.phone);
    setShowBdSuggestions(false);
    setShowNameSuggestions(false);
    setIsDirty(true);

    const prevOrder = state.airmanOrders
      .filter((o) => o.customerBdNumber === customer.bdNumber)
      .sort((a, b) => b.orderNumber - a.orderNumber)[0];

    if (prevOrder && (prevOrder.shirtMeasurements || prevOrder.pantMeasurements)) {
      if (prevOrder.shirtMeasurements) setShirt(prevOrder.shirtMeasurements);
      if (prevOrder.pantMeasurements) setPant(prevOrder.pantMeasurements);
      setMeasurementsLoadedNote(`Measurements loaded from order #${prevOrder.orderNumber}`);
      setOfferMeasurementPrompt(null);
    }
  };

  const handleBdBlur = () => {
    setTimeout(() => {
      setShowBdSuggestions(false);
    }, 250);

    if (!bdDigits) return;
    const normalized = normalizeBdNumber(bdDigits);
    const existing = state.customers.find(
      (c) => c.category === 'Airman' && c.bdNumber === normalized
    );

    if (existing) {
      if (customerName && customerName.trim().toLowerCase() !== existing.name.toLowerCase()) {
        setSavedNameNotice(`Using saved name: "${existing.name}" (was "${customerName}")`);
      }
      setCustomerName(existing.name);
      if (existing.phone && !phone) setPhone(existing.phone);

      const prevOrder = state.airmanOrders
        .filter((o) => o.customerBdNumber === existing.bdNumber)
        .sort((a, b) => b.orderNumber - a.orderNumber)[0];

      if (prevOrder && (prevOrder.shirtMeasurements || prevOrder.pantMeasurements)) {
        setOfferMeasurementPrompt({
          orderNumber: prevOrder.orderNumber,
          shirt: prevOrder.shirtMeasurements,
          pant: prevOrder.pantMeasurements,
        });
      }
    }
  };

  const handleApplyOfferedMeasurements = () => {
    if (offerMeasurementPrompt) {
      if (offerMeasurementPrompt.shirt) setShirt(offerMeasurementPrompt.shirt);
      if (offerMeasurementPrompt.pant) setPant(offerMeasurementPrompt.pant);
      setMeasurementsLoadedNote(
        `Measurements loaded from order #${offerMeasurementPrompt.orderNumber}`
      );
      setOfferMeasurementPrompt(null);
      setIsDirty(true);
    }
  };

  const handleClearLoadedMeasurements = () => {
    setShirt(INITIAL_SHIRT_MEASUREMENTS);
    setPant(INITIAL_PANT_MEASUREMENTS);
    setMeasurementsLoadedNote('');
    setIsDirty(true);
  };

  // Item rows operations
  const handleAddItemRow = () => {
    const first = state.settings.airmanItems[0];
    const newRow: AirmanOrderItem = {
      id: `air-item-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      name: first?.name || 'Item',
      quantity: 1,
      ivNumber: '',
    };
    setItems((prev) => [...prev, newRow]);
    setIsDirty(true);
  };

  const handleRemoveItemRow = (index: number) => {
    if (items.length <= 1) return;
    setItems((prev) => prev.filter((_, i) => i !== index));
    setIsDirty(true);
  };

  const handleChangeRowItem = (index: number, itemName: string) => {
    setItems((prev) =>
      prev.map((row, i) => {
        if (i !== index) return row;
        return { ...row, name: itemName };
      })
    );
    setOpenItemDropdownIndex(null);
    setIsDirty(true);
  };

  const handleChangeRowQuantity = (index: number, quantity: number) => {
    const qty = Math.max(1, Math.min(10, quantity));
    setItems((prev) =>
      prev.map((row, i) => {
        if (i !== index) return row;
        return { ...row, quantity: qty };
      })
    );
    setIsDirty(true);
  };

  const handleChangeRowIv = (index: number, iv: string) => {
    setItems((prev) =>
      prev.map((row, i) => {
        if (i !== index) return row;
        return { ...row, ivNumber: iv };
      })
    );
    setIsDirty(true);
  };

  // Inline Add Running Year
  const handleSaveNewYear = () => {
    setAddYearError('');
    const validation = validateRunningYear(newYearInput);
    if (!validation.valid || !validation.normalized) {
      setAddYearError(validation.error || 'Invalid year format. Use YYYY–YYYY (e.g. 2026–2027)');
      return;
    }

    addRunningYear(validation.normalized);
    setRunningYear(validation.normalized);
    setIsAddingYear(false);
    setNewYearInput('');
    setIsDirty(true);
  };

  // Draft operations
  const canSaveAsDraft = useMemo(() => {
    return Boolean(bdDigits && (items.length > 0 || (isEditingRowTouched && editingRow.ivNumber.trim())));
  }, [bdDigits, items, isEditingRowTouched, editingRow.ivNumber]);

  const handleSaveAsDraft = () => {
    if (!canSaveAsDraft) {
      setFormError('To save as draft, please provide at least BD number and 1 item.');
      return;
    }

    let draftItems = [...items];
    if (isEditingRowTouched && editingRow.catalogItem && editingRow.ivNumber.trim()) {
      draftItems.push({
        id: `air-item-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
        name: editingRow.catalogItem.name,
        quantity: editingRow.quantity,
        ivNumber: editingRow.ivNumber.trim(),
      });
    }

    const payload = {
      id: draftId,
      category: 'Airman' as const,
      customerBdNumber: normalizeBdNumber(bdDigits),
      customerName: customerName || `Airman (${bdDigits})`,
      customerPhone: phone,
      trade: existingOrder?.trade || existingDraft?.trade || '',
      ribbon,
      office: existingOrder?.office || existingDraft?.office || '',
      runningYear,
      orderDate,
      deliveryDate,
      airmanItems: draftItems,
      shirtMeasurements: shirt,
      pantMeasurements: pant,
    };

    saveDraft(payload);
    localStorage.removeItem(LOCAL_AIR_DRAFT_KEY);
    setIsDirty(false);
    onNavigate('drafts');
  };

  // Save Final Order
  const handleSaveOrder = (actionAfter?: 'print-slip') => {
    setFormError('');

    if (!bdDigits.trim()) {
      setFormError('BD Number is required.');
      return;
    }
    if (!customerName.trim()) {
      setFormError('Customer Name is required.');
      return;
    }

    let finalItems = [...items];
    if (isEditingRowTouched && editingRow.catalogItem) {
      if (!editingRow.ivNumber.trim()) {
        setFormError('IV-Number is required before saving the open item.');
        return;
      }
      finalItems.push({
        id: `air-item-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
        name: editingRow.catalogItem.name,
        quantity: editingRow.quantity,
        ivNumber: editingRow.ivNumber.trim(),
      });
    }

    if (finalItems.length === 0) {
      setFormError('Order must have at least one item.');
      return;
    }

    const orderData: any = {
      id: isEdit && existingOrder ? existingOrder.id : `air-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
      orderNumber: isEdit && existingOrder ? existingOrder.orderNumber : undefined,
      category: 'Airman',
      customerBdNumber: normalizeBdNumber(bdDigits),
      customerName: customerName.trim(),
      customerPhone: phone.trim(),
      trade: existingOrder?.trade || existingDraft?.trade || '',
      ribbon,
      office: existingOrder?.office || existingDraft?.office || '',
      runningYear,
      orderDate,
      deliveredDate: deliveryDate || undefined,
      status: isEdit && existingOrder ? existingOrder.status : 'Pending',
      items: finalItems,
      shirtMeasurements: shirt,
      pantMeasurements: pant,
      createdAt: isEdit && existingOrder ? existingOrder.createdAt : new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    const res = saveAirmanOrder(orderData, draftId);
    if (!res.success) {
      setFormError(res.error || 'Failed to save order.');
      return;
    }

    const finalNumber = res?.order?.orderNumber || orderData.orderNumber;
    localStorage.removeItem(LOCAL_AIR_DRAFT_KEY);
    if (draftId) deleteDraft(draftId);
    setIsDirty(false);

    if (actionAfter === 'print-slip') {
      onNavigate('print-slip', { orderNumber: finalNumber, category: 'Airman' });
    } else {
      onNavigate('airman-orders');
    }
  };

  const handleCancelClick = () => {
    if (!isDirty && !bdDigits && !customerName) {
      onNavigate('airman-orders');
      return;
    }
    setCancelModalOpen(true);
  };

  return (
    <PolarisPage
      title={isEdit ? `Edit Airman Order #${orderNumber}` : isDraftMode ? 'Airman Draft Order' : 'New Airman Order'}
      subtitle={isEdit ? 'Update military allocations, items, and measurements' : 'Create standard issue Bangladesh Air Force airman uniform'}
      badge={
        isDraftMode ? (
          <PolarisBadge tone="warning">Draft Mode</PolarisBadge>
        ) : isEdit ? (
          <PolarisBadge tone="warning">Editing Airman</PolarisBadge>
        ) : (
          <PolarisBadge tone="warning">Airman Allocation</PolarisBadge>
        )
      }
      backAction={handleCancelClick}
      secondaryActions={[
        {
          label: 'Cancel',
          onClick: handleCancelClick,
        },
        ...(!isEdit
          ? [
              {
                label: isDraftMode ? 'Update Draft' : 'Save as Draft',
                disabled: !canSaveAsDraft,
                onClick: handleSaveAsDraft,
              },
            ]
          : []),
        ...(!isDraftMode
          ? [
              {
                label: 'Cutting Slip',
                onClick: () => handleSaveOrder('print-slip'),
              },
            ]
          : []),
      ]}
      primaryAction={{
        label: isEdit ? 'Update Order' : 'Save Order',
        onClick: () => handleSaveOrder(),
      }}
    >
      {/* Resume Autosaved Prompt */}
      <ConfirmModal
        isOpen={resumePromptOpen}
        title="Continue where you left off?"
        message="You have unsaved changes from a previous session on this device. Would you like to restore them?"
        confirmLabel="Continue"
        cancelLabel="Start fresh"
        confirmVariant="primary"
        onConfirm={loadLocalDraft}
        onCancel={clearLocalDraft}
      />

      {/* Delete Draft Modal */}
      <ConfirmModal
        isOpen={deleteDraftModalOpen}
        title="Delete this draft?"
        message="This Airman draft will be permanently removed and cannot be recovered."
        confirmLabel="Delete Draft"
        cancelLabel="Cancel"
        confirmVariant="danger"
        onConfirm={() => {
          if (draftId) {
            deleteDraft(draftId);
            localStorage.removeItem(LOCAL_AIR_DRAFT_KEY);
            setIsDirty(false);
            onNavigate('drafts');
          }
        }}
        onCancel={() => setDeleteDraftModalOpen(false)}
      />

      {/* 3-choice Unsaved Changes Dialog */}
      {cancelModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/40 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl max-w-md w-full p-6 shadow-xl border border-[#E3E3E3]">
            <h3 className="text-base font-bold text-[#1A1A1A] mb-2">Unfinished Airman Order</h3>
            <p className="text-xs text-[#616161] mb-5 leading-relaxed">
              You have unsaved work. Would you like to stay on this page, leave without saving, or save as a draft?
            </p>
            {!canSaveAsDraft && (
              <p className="text-xs text-[#5E4200] bg-[#FFEA8A] p-2.5 rounded-lg mb-4">
                Drafts require at least a BD number and one item.
              </p>
            )}
            <div className="flex flex-col sm:flex-row justify-end gap-2">
              <button
                type="button"
                onClick={() => setCancelModalOpen(false)}
                className="px-3 py-1.5 text-xs font-semibold text-[#616161] hover:bg-[#F4F4F4] rounded-lg order-3 sm:order-1"
              >
                Stay on page
              </button>
              <button
                type="button"
                onClick={() => {
                  setCancelModalOpen(false);
                  localStorage.removeItem(LOCAL_AIR_DRAFT_KEY);
                  setIsDirty(false);
                  onNavigate('airman-orders');
                }}
                className="px-3 py-1.5 text-xs font-semibold text-[#8E0B21] hover:bg-[#FBEAE5] rounded-lg order-2"
              >
                Leave without saving
              </button>
              <button
                type="button"
                disabled={!canSaveAsDraft}
                onClick={() => {
                  setCancelModalOpen(false);
                  handleSaveAsDraft();
                }}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg text-white order-1 sm:order-3 shadow-xs ${
                  canSaveAsDraft ? 'bg-[#303030] hover:bg-[#1A1A1A]' : 'bg-[#E3E3E3] text-[#8C9196] cursor-not-allowed'
                }`}
              >
                Save as Draft
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Notification Banners */}
      {formError && (
        <div className="mb-4 p-3 bg-[#FBEAE5] border border-[#FED3D1] rounded-lg flex items-start space-x-2.5 text-[#8E0B21] text-xs font-medium">
          <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
          <span>{formError}</span>
        </div>
      )}

      {savedNameNotice && (
        <div className="mb-4 p-3 bg-[#FFEA8A] rounded-lg text-xs text-[#5E4200] font-medium flex items-center justify-between">
          <span>{savedNameNotice}</span>
          <button onClick={() => setSavedNameNotice('')} className="text-[#5E4200] font-bold ml-2">
            ✕
          </button>
        </div>
      )}

      {/* Main Two-Column Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column (Items with IV numbers & Measurements): 8 cols */}
        <div className="lg:col-span-8 space-y-6">
          {/* 1. Minimized Airman Items Card */}
          <CompactAirmanItemsPicker
            items={items}
            onChange={(newItems) => {
              setItems(newItems);
              setIsDirty(true);
            }}
            availableItems={state.settings.airmanItems || []}
            editingRow={editingRow}
            onEditingRowChange={(row, touched) => {
              setEditingRow(row);
              if (touched) {
                setIsEditingRowTouched(true);
                setIsDirty(true);
              }
            }}
            isEditingRowTouched={isEditingRowTouched}
          />

          {/* 2. Measurements Card */}
          <PolarisCard
            title="2. Measurements"
            actions={
              measurementsLoadedNote ? (
                <button
                  type="button"
                  onClick={handleClearLoadedMeasurements}
                  className="text-xs font-semibold text-[#8E0B21] hover:underline"
                >
                  Clear Loaded
                </button>
              ) : undefined
            }
          >
            {measurementsLoadedNote && (
              <div className="mb-4 p-2.5 bg-[#EAFBE7] border border-[#BBE5B3] rounded-lg text-xs text-[#0C5132] font-semibold flex items-center justify-between">
                <span>{measurementsLoadedNote}</span>
              </div>
            )}

            {offerMeasurementPrompt && !measurementsLoadedNote && (
              <div className="mb-4 p-3 bg-[#FFEA8A] rounded-lg flex items-center justify-between text-xs text-[#5E4200]">
                <span>Airman has measurements on order #{offerMeasurementPrompt.orderNumber}.</span>
                <button
                  type="button"
                  onClick={handleApplyOfferedMeasurements}
                  className="px-2.5 py-1 bg-[#005BD3] hover:bg-[#004BB3] text-white rounded font-semibold text-xs shadow-2xs"
                >
                  Use Order #{offerMeasurementPrompt.orderNumber}
                </button>
              </div>
            )}

            <div className="space-y-5">
              {/* Shirt Section */}
              <div className="p-4 border border-[#E3E3E3] rounded-lg bg-[#FAFBFB] space-y-3">
                <div className="flex items-center space-x-2 text-xs font-bold text-[#1A1A1A] uppercase tracking-wide">
                  <Ruler className="w-3.5 h-3.5 text-[#616161]" />
                  <span>Shirt Measurements</span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2.5">
                  {[
                    ['length', 'Length'],
                    ['chest', 'Chest'],
                    ['belly', 'Belly'],
                    ['hip', 'Hip'],
                    ['shoulder', 'Shoulder'],
                    ['sleeve', 'Sleeve'],
                    ['collar', 'Collar'],
                    ['front', 'Front'],
                    ['back', 'Back'],
                  ].map(([key, label]) => (
                    <div key={key}>
                      <label className="block text-[11px] font-medium text-[#616161] mb-1">{label}</label>
                      <input
                        type="text"
                        value={(shirt as any)[key]}
                        onChange={(e) => {
                          setShirt({ ...shirt, [key]: e.target.value });
                          setIsDirty(true);
                        }}
                        className="w-full px-2.5 py-1 text-xs bg-white border border-[#D4D4D4] rounded-md focus:outline-none focus:border-[#303030]"
                      />
                    </div>
                  ))}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                  <div>
                    <label className="block text-[11px] font-medium text-[#616161] mb-1">Hand Written Notes</label>
                    <textarea
                      rows={2}
                      value={shirt.handWrittenNotes}
                      onChange={(e) => {
                        setShirt({ ...shirt, handWrittenNotes: e.target.value });
                        setIsDirty(true);
                      }}
                      className="w-full px-2.5 py-1.5 text-xs bg-white border border-[#D4D4D4] rounded-md focus:outline-none focus:border-[#303030]"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-medium text-[#616161] mb-1">Extra Notes</label>
                    <textarea
                      rows={2}
                      value={shirt.extraNotes}
                      onChange={(e) => {
                        setShirt({ ...shirt, extraNotes: e.target.value });
                        setIsDirty(true);
                      }}
                      className="w-full px-2.5 py-1.5 text-xs bg-white border border-[#D4D4D4] rounded-md focus:outline-none focus:border-[#303030]"
                    />
                  </div>
                </div>
              </div>

              {/* Pant Section */}
              <div className="p-4 border border-[#E3E3E3] rounded-lg bg-[#FAFBFB] space-y-3">
                <div className="flex items-center space-x-2 text-xs font-bold text-[#1A1A1A] uppercase tracking-wide">
                  <Ruler className="w-3.5 h-3.5 text-[#616161]" />
                  <span>Pant Measurements</span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2.5">
                  {[
                    ['length', 'Length'],
                    ['waist', 'Waist'],
                    ['hip', 'Hip'],
                    ['high', 'High'],
                    ['thai', 'Thai'],
                    ['legOpen', 'Leg Open'],
                  ].map(([key, label]) => (
                    <div key={key}>
                      <label className="block text-[11px] font-medium text-[#616161] mb-1">{label}</label>
                      <input
                        type="text"
                        value={(pant as any)[key]}
                        onChange={(e) => {
                          setPant({ ...pant, [key]: e.target.value });
                          setIsDirty(true);
                        }}
                        className="w-full px-2.5 py-1.5 text-xs bg-white border border-[#D4D4D4] rounded-md focus:outline-none focus:border-[#303030]"
                      />
                    </div>
                  ))}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                  <div>
                    <label className="block text-[11px] font-medium text-[#616161] mb-1">Hand Written Notes</label>
                    <textarea
                      rows={2}
                      value={pant.handWrittenNotes}
                      onChange={(e) => {
                        setPant({ ...pant, handWrittenNotes: e.target.value });
                        setIsDirty(true);
                      }}
                      className="w-full px-2.5 py-1.5 text-xs bg-white border border-[#D4D4D4] rounded-md focus:outline-none focus:border-[#303030]"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-medium text-[#616161] mb-1">Extra Notes</label>
                    <textarea
                      rows={2}
                      value={pant.extraNotes}
                      onChange={(e) => {
                        setPant({ ...pant, extraNotes: e.target.value });
                        setIsDirty(true);
                      }}
                      className="w-full px-2.5 py-1.5 text-xs bg-white border border-[#D4D4D4] rounded-md focus:outline-none focus:border-[#303030]"
                    />
                  </div>
                </div>
              </div>
            </div>
          </PolarisCard>
        </div>

        {/* Right Column (Customer & Military Details): 4 cols */}
        <div className="lg:col-span-4 space-y-6">
          <PolarisCard title="3. Customer & Military Details">
            <div className="space-y-4">
              {/* BD Number (Numeric Keypad + Suggestions) */}
              <div className="relative">
                <label className="block text-xs font-semibold text-[#1A1A1A] mb-1">
                  BD Number <span className="text-[#8E0B21]">*</span>
                </label>
                <div className="flex rounded-md shadow-2xs">
                  <span className="inline-flex items-center px-2.5 rounded-l-md border border-r-0 border-[#D4D4D4] bg-[#EBEBEB] text-[#616161] text-xs font-bold">
                    BD/
                  </span>
                  <input
                    type="text"
                    inputMode="numeric"
                    pattern="[0-9]*"
                    value={bdDigits}
                    onFocus={() => setShowBdSuggestions(true)}
                    onBlur={handleBdBlur}
                    onChange={(e) => {
                      const val = e.target.value.replace(/\D/g, '');
                      setBdDigits(val);
                      setShowBdSuggestions(true);
                      setIsDirty(true);
                    }}
                    placeholder="10380"
                    className="flex-1 min-w-0 block w-full px-2.5 py-1.5 text-xs bg-white border border-[#D4D4D4] rounded-r-md focus:outline-none focus:border-[#303030] font-semibold"
                  />
                </div>

                {/* Suggestions Popover */}
                {showBdSuggestions && bdSuggestions.length > 0 && (
                  <div className="absolute z-20 left-0 right-0 mt-1 bg-white border border-[#E3E3E3] rounded-lg shadow-xl max-h-56 overflow-y-auto divide-y divide-[#E3E3E3]">
                    {bdSuggestions.map(({ customer: c, lastOrderDate, lastOrderNumber }) => (
                      <div
                        key={c.id}
                        onMouseDown={() => handleSelectCustomer(c)}
                        className="px-3 py-2 hover:bg-[#F4F4F4] cursor-pointer text-xs flex justify-between items-center"
                      >
                        <div>
                          <div className="font-bold text-[#1A1A1A]">{c.bdNumber}</div>
                          <div className="text-[#616161]">{c.name}</div>
                        </div>
                        <div className="text-right text-[11px] text-[#616161]">
                          {lastOrderNumber ? (
                            <span>#{lastOrderNumber} ({lastOrderDate})</span>
                          ) : (
                            <span>No prior order</span>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Customer Name */}
              <div className="relative">
                <label className="block text-xs font-semibold text-[#1A1A1A] mb-1">
                  Customer Name <span className="text-[#8E0B21]">*</span>
                </label>
                <input
                  type="text"
                  value={customerName}
                  onFocus={() => setShowNameSuggestions(true)}
                  onBlur={() => setTimeout(() => setShowNameSuggestions(false), 200)}
                  onChange={(e) => {
                    setCustomerName(e.target.value);
                    setShowNameSuggestions(true);
                    setIsDirty(true);
                  }}
                  placeholder="e.g. Sgt. Alam"
                  className="w-full px-2.5 py-1.5 text-xs bg-white border border-[#D4D4D4] rounded-md focus:outline-none focus:border-[#303030] shadow-2xs font-semibold"
                />
                {showNameSuggestions && nameSuggestions.length > 0 && (
                  <div className="absolute z-20 left-0 right-0 mt-1 bg-white border border-[#E3E3E3] rounded-lg shadow-xl max-h-56 overflow-y-auto divide-y divide-[#E3E3E3]">
                    {nameSuggestions.map(({ customer: c }) => (
                      <div
                        key={c.id}
                        onMouseDown={() => handleSelectCustomer(c)}
                        className="px-3 py-2 hover:bg-[#F4F4F4] cursor-pointer text-xs flex justify-between items-center"
                      >
                        <span className="font-bold text-[#1A1A1A]">{c.name}</span>
                        <span className="text-xs text-[#005BD3] font-mono">{c.bdNumber}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Phone */}
              <div>
                <label className="block text-xs font-semibold text-[#1A1A1A] mb-1">Phone</label>
                <input
                  type="text"
                  inputMode="numeric"
                  pattern="[0-9]*"
                  value={phone}
                  onChange={(e) => {
                    setPhone(e.target.value.replace(/\D/g, ''));
                    setIsDirty(true);
                  }}
                  placeholder="017XXXXXXXX"
                  className="w-full px-2.5 py-1.5 text-xs bg-white border border-[#D4D4D4] rounded-md focus:outline-none focus:border-[#303030] shadow-2xs"
                />
              </div>


              {/* Ribbon & Running Year */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-[#1A1A1A] mb-1">Ribbon</label>
                  <select
                    value={ribbon}
                    onChange={(e) => {
                      setRibbon(e.target.value);
                      setIsDirty(true);
                    }}
                    className="w-full px-2.5 py-1.5 text-xs bg-white border border-[#D4D4D4] rounded-md focus:outline-none focus:border-[#303030] shadow-2xs font-medium"
                  >
                    {state.settings.ribbonValues.map((v) => (
                      <option key={v} value={v}>
                        {v}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-xs font-semibold text-[#1A1A1A]">Running Year</label>
                    <button
                      type="button"
                      onClick={() => setIsAddingYear(!isAddingYear)}
                      className="text-[10px] font-bold text-[#005BD3] hover:underline"
                    >
                      {isAddingYear ? 'Cancel' : '+ Add'}
                    </button>
                  </div>
                  {!isAddingYear ? (
                    <select
                      value={runningYear}
                      onChange={(e) => {
                        setRunningYear(e.target.value);
                        setIsDirty(true);
                      }}
                      className="w-full px-2.5 py-1.5 text-xs bg-white border border-[#D4D4D4] rounded-md focus:outline-none focus:border-[#303030] shadow-2xs font-medium"
                    >
                      {state.settings.runningYears.map((yr) => (
                        <option key={yr} value={yr}>
                          {yr}
                        </option>
                      ))}
                    </select>
                  ) : (
                    <div className="space-y-1.5">
                      <div className="flex gap-1">
                        <input
                          type="text"
                          value={newYearInput}
                          onChange={(e) => setNewYearInput(e.target.value)}
                          placeholder="2027–2028"
                          className="w-full px-2 py-1 text-xs border border-[#D4D4D4] rounded-md bg-white"
                        />
                        <button
                          type="button"
                          onClick={handleSaveNewYear}
                          className="px-2 py-1 bg-[#303030] text-white text-[11px] font-semibold rounded-md shadow-2xs"
                        >
                          Save
                        </button>
                      </div>
                      {addYearError && (
                        <p className="text-[10px] text-[#8E0B21]">{addYearError}</p>
                      )}
                    </div>
                  )}
                </div>
              </div>

              {/* Dates */}
              <div className="grid grid-cols-2 gap-3 pt-1">
                <div>
                  <label className="block text-xs font-semibold text-[#1A1A1A] mb-1">Order Date</label>
                  <input
                    type="date"
                    value={orderDate}
                    onChange={(e) => {
                      setOrderDate(e.target.value);
                      setIsDirty(true);
                    }}
                    className="w-full px-2 py-1.5 text-xs bg-white border border-[#D4D4D4] rounded-md focus:outline-none focus:border-[#303030] shadow-2xs"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#1A1A1A] mb-1">Delivery Date</label>
                  <input
                    type="date"
                    value={deliveryDate}
                    onChange={(e) => {
                      setDeliveryDate(e.target.value);
                      setIsDirty(true);
                    }}
                    className="w-full px-2 py-1.5 text-xs bg-white border border-[#D4D4D4] rounded-md focus:outline-none focus:border-[#303030] shadow-2xs"
                  />
                </div>
              </div>
            </div>
          </PolarisCard>

          {/* Quick Action Panel */}
          <div className="p-4 bg-white border border-[#E3E3E3] rounded-lg space-y-2 shadow-2xs">
            <button
              type="button"
              onClick={() => handleSaveOrder()}
              className="w-full py-2 bg-[#303030] hover:bg-[#1A1A1A] text-white rounded-md text-xs font-semibold shadow-xs transition-colors"
            >
              {isEdit ? 'Update Order' : 'Save Order'}
            </button>
            {!isEdit && (
              <button
                type="button"
                onClick={handleSaveAsDraft}
                disabled={!canSaveAsDraft}
                className="w-full py-2 bg-white hover:bg-[#FAFBFB] text-[#616161] border border-[#D4D4D4] rounded-md text-xs font-medium transition-colors"
              >
                {isDraftMode ? 'Update Draft' : 'Save as Draft'}
              </button>
            )}
          </div>
        </div>
      </div>
    </PolarisPage>
  );
};
