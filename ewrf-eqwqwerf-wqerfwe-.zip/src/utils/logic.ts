import { AirmanOrder, DiscountType, OfficerOrder, PaymentRecord, WorkerEntryRow, WorkerPayment, SlipType, ShirtMeasurements, PantMeasurements } from '../types/index.ts';

/**
 * Parses and calculates discount amount given a raw value and default type.
 */
export function calculateDiscount(
  total: number,
  discountValue: string | undefined,
  defaultType: DiscountType
): { amount: number; type: DiscountType } {
  if (!discountValue || discountValue.trim() === '') {
    return { amount: 0, type: defaultType };
  }

  const raw = discountValue.trim();
  const isPercentExplicit = raw.includes('%');
  const numValue = parseFloat(raw.replace(/%/g, ''));

  if (isNaN(numValue) || numValue <= 0) {
    return { amount: 0, type: defaultType };
  }

  const resolvedType: DiscountType = isPercentExplicit ? 'percentage' : defaultType;

  let amount = 0;
  if (resolvedType === 'percentage') {
    amount = Math.round((total * numValue) / 100);
  } else {
    amount = Math.round(numValue);
  }

  // Discount cannot exceed total
  amount = Math.min(amount, total);
  return { amount, type: resolvedType };
}

/**
 * Calculates due amount on an Officer order.
 * Due = Total − Discount − Advance − all Pay amounts received so far.
 * Never negative.
 */
export function calculateDue(
  total: number,
  discountAmount: number,
  advance: number,
  payments: PaymentRecord[] = []
): number {
  const paymentsTotal = payments.reduce((sum, p) => sum + (Number(p.amount) || 0), 0);
  const due = total - discountAmount - (advance || 0) - paymentsTotal;
  return Math.max(0, due);
}

/**
 * Total money already received on an order (advance + subsequent Pay records).
 */
export function calculateMoneyReceived(advance: number, payments: PaymentRecord[] = []): number {
  const paymentsTotal = payments.reduce((sum, p) => sum + (Number(p.amount) || 0), 0);
  return (advance || 0) + paymentsTotal;
}

/**
 * Checks if new total amount after discount is sufficient to cover already received money.
 * If money already received is more than the new total, saving is blocked.
 */
export function isNewTotalValidForReceived(totalAfterDiscount: number, alreadyReceived: number): boolean {
  return alreadyReceived <= totalAfterDiscount;
}

/**
 * Renumbers orders when an order is deleted.
 * All later orders in the same category move down by one.
 */
export function renumberOrdersOnDelete<T extends { orderNumber: number; id: string }>(
  orders: T[],
  deletedOrderNumber: number
): T[] {
  return orders
    .filter((o) => o.orderNumber !== deletedOrderNumber)
    .map((o) => {
      if (o.orderNumber > deletedOrderNumber) {
        return { ...o, orderNumber: o.orderNumber - 1 };
      }
      return o;
    });
}

/**
 * Renumbers orders when an order is restored as #N.
 * Every current order in that category with orderNumber >= N moves up by 1.
 * If N > max(orderNumber) + 1, it takes max(orderNumber) + 1.
 */
export function renumberOrdersOnRestore<T extends { orderNumber: number; id: string }>(
  orders: T[],
  orderToRestore: T
): { updatedOrders: T[]; restoredOrder: T } {
  const currentMax = orders.reduce((max, o) => Math.max(max, o.orderNumber), 0);
  const targetNumber =
    orderToRestore.orderNumber > currentMax + 1 ? currentMax + 1 : orderToRestore.orderNumber;

  const shiftedOrders = orders.map((o) => {
    if (o.orderNumber >= targetNumber) {
      return { ...o, orderNumber: o.orderNumber + 1 };
    }
    return o;
  });

  const restored: T = { ...orderToRestore, orderNumber: targetNumber };
  const updatedOrders = [restored, ...shiftedOrders].sort((a, b) => b.orderNumber - a.orderNumber);

  return { updatedOrders, restoredOrder: restored };
}

/**
 * Validates running year format: two consecutive years e.g. 2027–2028 or 2027-2028
 */
export function validateRunningYear(yearStr: string): { valid: boolean; normalized?: string; error?: string } {
  const trimmed = yearStr.trim();
  const match = trimmed.match(/^(\d{4})[–\-](\d{4})$/);
  if (!match) {
    return { valid: false, error: 'Format must be two consecutive years, e.g. 2027–2028' };
  }
  const y1 = parseInt(match[1], 10);
  const y2 = parseInt(match[2], 10);
  if (y2 !== y1 + 1) {
    return { valid: false, error: 'Years must be consecutive, e.g. 2027–2028' };
  }
  return { valid: true, normalized: `${y1}–${y2}` };
}

/**
 * Normalizes BD numbers to BD/XXXXX
 */
export function normalizeBdNumber(raw: string): string {
  if (!raw) return '';
  const digits = raw.replace(/\D/g, '');
  return digits ? `BD/${digits}` : raw.trim();
}

export function getBdDigits(raw: string): string {
  return (raw || '').replace(/\D/g, '');
}

/**
 * Finds latest order for customer in category to load measurements.
 * Excludes handWrittenNotes and extraNotes.
 */
export function getLatestMeasurementsForCustomer(
  bdNumber: string,
  category: 'Officer' | 'Airman',
  officerOrders: OfficerOrder[],
  airmanOrders: AirmanOrder[]
): {
  found: boolean;
  orderNumber?: number;
  shirt?: any;
  pant?: any;
} {
  const norm = normalizeBdNumber(bdNumber).toUpperCase();
  const digits = getBdDigits(bdNumber);

  const matchOrder = (oBd: string) => {
    const oNorm = normalizeBdNumber(oBd).toUpperCase();
    const oDigits = getBdDigits(oBd);
    return (norm && oNorm === norm) || (digits && oDigits === digits);
  };

  if (category === 'Officer') {
    const matching = officerOrders
      .filter((o) => matchOrder(o.customerBdNumber))
      .sort((a, b) => b.orderNumber - a.orderNumber);
    if (matching.length > 0) {
      const latest = matching[0];
      const { handWrittenNotes: _sH, extraNotes: _sE, ...shirt } = latest.shirtMeasurements || ({} as any);
      const { handWrittenNotes: _pH, extraNotes: _pE, ...pant } = latest.pantMeasurements || ({} as any);
      return {
        found: true,
        orderNumber: latest.orderNumber,
        shirt: { ...shirt, handWrittenNotes: '', extraNotes: '' },
        pant: { ...pant, handWrittenNotes: '', extraNotes: '' },
      };
    }
  } else {
    const matching = airmanOrders
      .filter((o) => matchOrder(o.customerBdNumber))
      .sort((a, b) => b.orderNumber - a.orderNumber);
    if (matching.length > 0) {
      const latest = matching[0];
      const { handWrittenNotes: _sH, extraNotes: _sE, ...shirt } = latest.shirtMeasurements || ({} as any);
      const { handWrittenNotes: _pH, extraNotes: _pE, ...pant } = latest.pantMeasurements || ({} as any);
      return {
        found: true,
        orderNumber: latest.orderNumber,
        shirt: { ...shirt, handWrittenNotes: '', extraNotes: '' },
        pant: { ...pant, handWrittenNotes: '', extraNotes: '' },
      };
    }
  }
  return { found: false };
}

/**
 * Format Date to YYYY-MM-DD in local time
 */
export function formatDate(d: Date = new Date()): string {
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

/**
 * Format Date to YYYY-MM
 */
export function formatMonth(d: Date = new Date()): string {
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  return `${year}-${month}`;
}

/**
 * Adds days to a date string YYYY-MM-DD
 */
export function addDays(dateStr: string, days: number): string {
  const d = new Date(dateStr + 'T00:00:00');
  d.setDate(d.getDate() + days);
  return formatDate(d);
}

/**
 * Checks if an order is upcoming.
 * The number of orders that are not Delivered and whose delivery date is
 * from today up to today plus the Upcoming delivery days number from Settings.
 * Orders without a delivery date are not counted.
 */
export function isOrderUpcoming(
  deliveryDate: string | undefined,
  isDelivered: boolean,
  today: string,
  upcomingDays: number
): boolean {
  if (isDelivered || !deliveryDate || deliveryDate.trim() === '') {
    return false;
  }
  const maxDate = addDays(today, upcomingDays);
  return deliveryDate >= today && deliveryDate <= maxDate;
}

/**
 * Validates IV-numbers for Airman orders.
 * An IV-Number belongs to one person. If it is already used on an Airman order
 * of a DIFFERENT BD number, do not save. The same person may repeat an IV-Number.
 */
export function validateAirmanIvNumbers(
  items: { ivNumber: string }[],
  customerBdNumber: string,
  existingOrders: AirmanOrder[],
  currentOrderId?: string
): { valid: boolean; error?: string } {
  const normalizedBd = customerBdNumber.trim().toUpperCase();

  // Build map of used IV numbers -> BD numbers from all other orders
  for (const order of existingOrders) {
    if (currentOrderId && order.id === currentOrderId) {
      continue;
    }
    const orderBd = order.customerBdNumber.trim().toUpperCase();
    if (orderBd !== normalizedBd) {
      for (const item of order.items) {
        const iv = (item.ivNumber || '').trim();
        if (!iv) continue;
        const conflict = items.find((i) => (i.ivNumber || '').trim().toUpperCase() === iv.toUpperCase());
        if (conflict) {
          return {
            valid: false,
            error: `IV-Number ${conflict.ivNumber} already belongs to BD ${order.customerBdNumber}.`,
          };
        }
      }
    }
  }

  return { valid: true };
}

/**
 * Returns date range for period filters.
 * Weeks run Saturday to Friday.
 */
export function getPeriodRange(
  period: 'Today' | 'This Week' | 'Last Week' | 'This Month' | 'Last Month' | 'This Year' | 'All Time' | 'Pick Month',
  customMonth?: string,
  refDate: Date = new Date()
): { start: string; end: string } | null {
  if (period === 'All Time') {
    return null;
  }

  const todayStr = formatDate(refDate);

  if (period === 'Today') {
    return { start: todayStr, end: todayStr };
  }

  if (period === 'This Month') {
    const ym = formatMonth(refDate);
    const lastDay = new Date(refDate.getFullYear(), refDate.getMonth() + 1, 0).getDate();
    return { start: `${ym}-01`, end: `${ym}-${String(lastDay).padStart(2, '0')}` };
  }

  if (period === 'Last Month') {
    const prevMonthDate = new Date(refDate.getFullYear(), refDate.getMonth() - 1, 1);
    const ym = formatMonth(prevMonthDate);
    const lastDay = new Date(prevMonthDate.getFullYear(), prevMonthDate.getMonth() + 1, 0).getDate();
    return { start: `${ym}-01`, end: `${ym}-${String(lastDay).padStart(2, '0')}` };
  }

  if (period === 'Pick Month' && customMonth) {
    const [y, m] = customMonth.split('-').map(Number);
    const lastDay = new Date(y, m, 0).getDate();
    return { start: `${customMonth}-01`, end: `${customMonth}-${String(lastDay).padStart(2, '0')}` };
  }

  if (period === 'This Year') {
    const y = refDate.getFullYear();
    return { start: `${y}-01-01`, end: `${y}-12-31` };
  }

  if (period === 'This Week' || period === 'Last Week') {
    // Saturday is day 6 in JS Date (Sunday is 0)
    // Saturday to Friday
    const dayOfWeek = refDate.getDay(); // 0 = Sun, 1 = Mon ... 6 = Sat
    // Days since last Saturday:
    const daysSinceSaturday = (dayOfWeek + 1) % 7;
    const thisSat = new Date(refDate);
    thisSat.setDate(refDate.getDate() - daysSinceSaturday);

    if (period === 'This Week') {
      const thisFri = new Date(thisSat);
      thisFri.setDate(thisSat.getDate() + 6);
      return { start: formatDate(thisSat), end: formatDate(thisFri) };
    } else {
      const lastSat = new Date(thisSat);
      lastSat.setDate(thisSat.getDate() - 7);
      const lastFri = new Date(lastSat);
      lastFri.setDate(lastSat.getDate() + 6);
      return { start: formatDate(lastSat), end: formatDate(lastFri) };
    }
  }

  return null;
}

/**
 * Worker hishab calculations for a month or period
 */
export interface WorkerMonthHishab {
  totalAmount: number;
  totalKhoroch: number;
  netPayable: number;
  received: number;
  due: number;
  status: 'Paid' | 'Partial' | 'Unpaid' | '—';
  worksCount: number;
}

export function calculateWorkerMonthHishab(
  workerId: string,
  rows: WorkerEntryRow[],
  payments: WorkerPayment[],
  monthStr?: string // YYYY-MM or undefined for all time
): WorkerMonthHishab {
  const filteredRows = rows.filter((r) => {
    if (r.workerId !== workerId) return false;
    if (!monthStr) return true;
    const rowMonth = (r.date || '').slice(0, 7);
    const khorochMonth = (r.khorochDate || r.date || '').slice(0, 7);
    return rowMonth === monthStr || khorochMonth === monthStr;
  });

  let totalAmount = 0;
  let totalKhoroch = 0;
  let worksCount = 0;

  for (const r of filteredRows) {
    const rowMonth = (r.date || '').slice(0, 7);
    const khorochMonth = (r.khorochDate || r.date || '').slice(0, 7);

    if (!monthStr || rowMonth === monthStr) {
      if (r.item && r.quantity > 0) {
        totalAmount += Number(r.totalTaka) || 0;
        worksCount += Number(r.quantity) || 0;
      }
    }

    if (!monthStr || khorochMonth === monthStr) {
      if (r.khoroch) {
        totalKhoroch += Number(r.khoroch) || 0;
      }
    }
  }

  const netPayable = totalAmount - totalKhoroch;

  const filteredPayments = payments.filter((p) => {
    if (p.workerId !== workerId) return false;
    if (!monthStr) return true;
    return p.forMonth === monthStr;
  });

  const received = filteredPayments.reduce((sum, p) => sum + (Number(p.amount) || 0), 0);
  const due = netPayable - received;

  let status: 'Paid' | 'Partial' | 'Unpaid' | '—' = '—';
  if (netPayable === 0 && received === 0) {
    status = '—';
  } else if (due <= 0 && netPayable > 0) {
    status = 'Paid';
  } else if (received > 0 && due > 0) {
    status = 'Partial';
  } else if (received === 0 && netPayable > 0) {
    status = 'Unpaid';
  }

  return {
    totalAmount,
    totalKhoroch,
    netPayable,
    received,
    due,
    status,
    worksCount,
  };
}

/**
 * Determines slip type for an item. Defaults by name:
 * Pant -> Pant
 * Shirt / Sleeve -> Shirt
 * Others -> Shirt + Pant
 */
export function getItemSlipType(itemName: string, explicitType?: SlipType): SlipType {
  if (explicitType) return explicitType;
  const lower = (itemName || '').toLowerCase();
  if (lower.includes('pant')) return 'Pant';
  if (lower.includes('shirt') || lower.includes('sleeve')) return 'Shirt';
  return 'Shirt + Pant';
}

/**
 * Formats shirt measurements for cutting slip according to FIX-20:
 * Fixed order: Length, Chest, Belly, Hip, Shoulder, Sleeve, Collar, Front shown as F-value, Back shown as B-value.
 * Joined with ' ~ ', empty skipped. If none, '—'.
 */
const withPrefix = (prefix: string, val?: string) => {
  if (!val || !val.trim()) return null;
  const clean = val.trim();
  if (clean.toLowerCase().startsWith(prefix.toLowerCase())) return clean;
  return `${prefix}${clean}`;
};

/**
 * Formats shirt measurements for cutting slip according to FIX-20:
 * Fixed order: L-Length ~ Ch-Chest ~ B-Belly ~ Hip-Hip ~ Sh-Shoulder ~ Sl-Sleeve ~ Col-Collar ~ F-Front ~ B-Back.
 * Joined with ' ~ ', empty skipped. If none, '—'.
 */
export function formatShirtMeasurementsSlip(m?: Partial<ShirtMeasurements>): string {
  if (!m) return '—';
  const parts: (string | null)[] = [
    withPrefix('L-', m.length),
    withPrefix('Ch-', m.chest),
    withPrefix('B-', m.belly),
    withPrefix('Hip-', m.hip),
    withPrefix('Sh-', m.shoulder),
    withPrefix('Sl-', m.sleeve),
    withPrefix('Col-', m.collar),
    withPrefix('F-', m.front),
    withPrefix('B-', m.back),
  ];
  const active = parts.filter(Boolean) as string[];
  return active.length > 0 ? active.join(' ~ ') : '—';
}

/**
 * Formats pant measurements for cutting slip according to FIX-20:
 * Fixed order: L-Length ~ W-Waist ~ Hip-Hip ~ High-High ~ Thai-Thai ~ Leg-LegOpen.
 * Joined with ' ~ ', empty skipped. If none, '—'.
 */
export function formatPantMeasurementsSlip(m?: Partial<PantMeasurements>): string {
  if (!m) return '—';
  const parts: (string | null)[] = [
    withPrefix('L-', m.length),
    withPrefix('W-', m.waist),
    withPrefix('Hip-', m.hip),
    withPrefix('High-', m.high),
    withPrefix('Thai-', m.thai),
    withPrefix('Leg-', m.legOpen),
  ];
  const active = parts.filter(Boolean) as string[];
  return active.length > 0 ? active.join(' ~ ') : '—';
}


